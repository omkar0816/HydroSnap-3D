import { useContext, useEffect, useMemo, useState } from "react"
import { Link, useLocation, useParams } from "react-router-dom"
import { jsPDF } from "jspdf"
import {
  Activity,
  ArrowDownToLine,
  ArrowRight,
  Check,
  ChevronDown,
  CircleHelp,
  Download,
  FileBarChart2,
  FileImage,
  Filter,
  Flag,
  Layers3,
  Leaf,
  MapPin as MapPinIcon,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Waves,
  X,
} from "lucide-react"
import { AppContext } from "@/App"
import { useHydroSnap } from "@/hooks/useHydroSnap"
import { useWatershedEvidence } from "@/hooks/useWatershedEvidence"
import { DemoBadge } from "@/components/common/DemoBadge"
import { TrustPanel } from "@/components/evidence/TrustPanel"
import {
  InterventionCard,
  type EvidenceIntervention,
} from "@/components/interventions/InterventionCard"
import { WatershedSatellitePanel } from "@/components/maps/WatershedSatellitePanel"
import { downloadObservationAudit } from "@/utils/exporters"
import {
  evidenceAssetsToAssets,
  evidenceObservationsToFieldObservations,
} from "@/utils/evidence"
import type { SavedWatershedReport } from "../../shared/reportFacts"
import type {
  AnalysisJob,
  Asset,
  FieldObservation,
  Intervention,
  Report,
  Watershed,
} from "@/types/domain"

type Section = "watersheds" | "watershed-detail" | "layers" | "analytics" | "evidence" | "interventions" | "reports" | "administration" | "settings"

const pageInfo: Record<Section, {
  title: string
  description: string
  kicker: string
}> = {
  watersheds: {
    title: "Watershed management",
    description:
      "Explore and manage watershed boundaries and monitoring coverage.",
    kicker: "SPATIAL INTELLIGENCE",
  },
  "watershed-detail": {
    title: "Watershed details",
    description: "Boundary, monitoring coverage and associated field activity.",
    kicker: "WATERSHED PROFILE",
  },
  layers: {
    title: "Thematic layers",
    description:
      "Review available spatial layers and satellite analysis overlays.",
    kicker: "SPATIAL INTELLIGENCE",
  },
  analytics: {
    title: "Change detection & analytics",
    description: "Run and review watershed environmental analysis jobs.",
    kicker: "SATELLITE INSIGHTS",
  },
  evidence: {
    title: "Field evidence",
    description: "Search, inspect and verify geo-coded field observations.",
    kicker: "FIELD OPERATIONS",
  },
  interventions: {
    title: "Interventions",
    description: "Monitor planned and active watershed development work.",
    kicker: "FIELD OPERATIONS",
  },
  reports: {
    title: "Reports",
    description: "Configure watershed, field inspection and analysis reports.",
    kicker: "OUTPUTS",
  },
  administration: {
    title: "Administration",
    description: "Manage roles, field teams and access-ready settings.",
    kicker: "SYSTEM",
  },
  settings: {
    title: "Settings",
    description:
      "Configure your workspace preferences and offline data settings.",
    kicker: "SYSTEM",
  },
}

const layerPresentation = {
  boundary: { icon: Waves, tint: "green" },
  streams: { icon: Waves, tint: "blue" },
  ndvi: { icon: Leaf, tint: "green" },
  ndwi: { icon: Layers3, tint: "cyan" },
}
const mapLayerKeys = ["boundary", "streams", "assets", "ndvi", "ndwi"] as const
type MapLayerKey = typeof mapLayerKeys[number]

export function WorkspacePage({ section }: { section: Section }) {
  const context = useContext(AppContext)
  const data = useHydroSnap({
    loadAssets: section !== "watershed-detail" && section !== "evidence" && section !== "interventions",
    loadObservations: section !== "watershed-detail" && section !== "evidence" && section !== "interventions",
    loadInterventions: section !== "watershed-detail" && section !== "evidence" && section !== "interventions",
  })
  const location = useLocation()
  const params = useParams()
  const [query, setQuery] = useState(
    new URLSearchParams(location.search).get("search") ?? "",
  )
  const [statusFilter, setStatusFilter] = useState("All statuses")
  const [assetTypeFilter, setAssetTypeFilter] = useState("All types")
  const [reportAssetId, setReportAssetId] = useState("")
    const [generatedReport, setGeneratedReport] = useState<SavedWatershedReport>()
    const [expandedFactId, setExpandedFactId] = useState<string>()
  const [busy, setBusy] = useState(false)
  const [selectedLayer, setSelectedLayer] = useState<string>()
  const [showInterventionForm, setShowInterventionForm] = useState(false)
  const [interventionName, setInterventionName] = useState("")
  const [interventionType, setInterventionType] = useState("")
  const [interventionStatus, setInterventionStatus] = useState<Intervention["status"]>("Planned")
  const [interventionInstalledAt, setInterventionInstalledAt] = useState("")
  const [interventionAssetId, setInterventionAssetId] = useState("")
  const [interventionFilter, setInterventionFilter] = useState<"Active" | "All">("Active")
  const watersheds = data.watersheds.data ?? []
  const thematicLayers = data.layers.data ?? []
  const analysisResults = data.results.data ?? []
  const latestIndex = (metric: "NDVI" | "NDWI") =>
    analysisResults.filter((result) => result.metric === metric).at(-1)
  const activeWatershed =
    watersheds.find(
      ({ id }) =>
        id ===
        (section === "watershed-detail"
          ? params.watershedId
          : context?.watershedId),
    ) ?? watersheds[0]
  const evidenceQuery = useWatershedEvidence(
    section === "watershed-detail" || section === "evidence" || section === "interventions"
      ? activeWatershed?.id
      : undefined,
  )
  const allAssets = useMemo(
    () => section === "watershed-detail" || section === "evidence" || section === "interventions"
      ? evidenceAssetsToAssets(evidenceQuery.data)
      : data.assets.data ?? [],
    [data.assets.data, evidenceQuery.data, section],
  )
  const scopedObservations = useMemo(
    () => section === "watershed-detail" || section === "evidence" || section === "interventions"
      ? evidenceObservationsToFieldObservations(evidenceQuery.data)
      : data.observations.data ?? [],
    [data.observations.data, evidenceQuery.data, section],
  )
  const assets = allAssets.filter(
    (asset) => asset.watershedId === activeWatershed?.id,
  )
  const allInterventions = evidenceQuery.data?.interventions ?? []
  const visibleInterventions = useMemo(
    () => interventionFilter === "Active"
      ? allInterventions.filter(({ status }) => status === "In progress")
      : allInterventions,
    [allInterventions, interventionFilter],
  )
  const canEditInterventions = ["Field Officer", "GIS Analyst", "Administrator"].includes(
    data.currentUser.data?.role ?? "",
  )
  const filteredAssets = useMemo(
    () =>
      allAssets.filter((asset) => {
        const matchesText =
          `${asset.name} ${asset.village} ${asset.type} ${asset.description}`
            .toLowerCase()
            .includes(query.toLowerCase())
        const matchesStatus =
          statusFilter === "All statuses" || asset.status === statusFilter
        const matchesType =
          assetTypeFilter === "All types" || asset.type === assetTypeFilter
        const matchesWatershed =
          section === "evidence" || asset.watershedId === activeWatershed?.id
        return matchesText && matchesStatus && matchesType && matchesWatershed
      }),
    [
      activeWatershed?.id,
      allAssets,
      assetTypeFilter,
      query,
      section,
      statusFilter,
    ],
  )
  const filteredWatersheds = watersheds.filter((watershed) =>
    `${watershed.name} ${watershed.code} ${watershed.district}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  )
  const searchParameter =
    new URLSearchParams(location.search).get("search") ?? ""

  useEffect(() => {
    setQuery(searchParameter)
  }, [searchParameter])

  async function makeAnalysis(type: AnalysisJob["type"]) {
    if (!activeWatershed) return
    setBusy(true)
    try {
      const job = await data.createAnalysis.mutateAsync({
        watershedId: activeWatershed.id,
        type,
      })
      context?.notify(`${type} sample analysis queued · ${job.id}`)
    } catch (error) {
      context?.notify(
        error instanceof Error ? error.message : "Could not start analysis.",
      )
    } finally {
      setBusy(false)
    }
  }

  async function makeReport() {
    if (!activeWatershed) return
    setBusy(true)
    try {
      const report = await data.generateWatershedReport.mutateAsync({
        watershedId: activeWatershed.id,
        language: "en",
      })
      setGeneratedReport(report)
      context?.notify("Validated watershed report saved.")
    } catch (error) {
      context?.notify(
        error instanceof Error ? error.message : "Could not create report.",
      )
    } finally {
      setBusy(false)
    }
  }

  async function startIntervention(item: EvidenceIntervention) {
    try {
      await data.updateIntervention.mutateAsync({ id: item.id, status: "In progress" })
      context?.notify("Work marked In progress. NDVI and NDWI analysis has been queued.")
    } catch (error) {
      context?.notify(error instanceof Error ? error.message : "Could not update the intervention.")
    }
  }

  async function refreshInterventionIndices(item: EvidenceIntervention) {
    try {
      await data.refreshInterventionIndices.mutateAsync(item.id)
      context?.notify("NDVI and NDWI refresh queued.")
    } catch (error) {
      context?.notify(error instanceof Error ? error.message : "Could not queue the satellite refresh.")
    }
  }

  async function verifyAsset(asset: Asset) {
    try {
      await data.verifyObservation.mutateAsync(asset.id)
      context?.notify(`${asset.name} marked verified.`)
    } catch (error) {
      context?.notify(
        error instanceof Error
          ? error.message
          : "Could not verify field observation.",
      )
    }
  }

  return (
    <div className="page-stack workspace-page">
      <div className="page-heading compact-heading">
        <div>
          <div className="eyebrow">
            <span className="eyebrow-mark" /> {pageInfo[section].kicker}
          </div>
          <h1>{pageInfo[section].title}</h1>
          <p>{pageInfo[section].description}</p>
        </div>
        {section === "evidence" ? (
          <Link to="/upload" className="button button-primary">
            <Plus size={16} /> Add observation
          </Link>
        ) : section === "watersheds" ? (
          <button
            className="button button-primary"
            onClick={() =>
              context?.notify("Not available in this prototype.")
            }
          >
            <Plus size={16} /> Add watershed
          </button>
        ) : null}
      </div>

      {section === "watersheds" && (
        <section className="panel workspace-table-panel">
          <div className="table-toolbar">
            <label className="table-search">
              <Search size={16} />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search watershed or code..."
              />
            </label>
            <span className="table-result-count">
              {filteredWatersheds.length} watersheds
            </span>
          </div>
          <div className="data-table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>WATERSHED</th>
                  <th>CODE</th>
                  <th>LOCATION</th>
                  <th>AREA</th>
                  <th>VILLAGES</th>
                  <th>STATUS</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {filteredWatersheds.map((watershed) => (
                  <tr key={watershed.id}>
                    <td>
                      <Link
                        className="table-primary-link"
                        to={`/watersheds/${watershed.id}`}
                      >
                        {watershed.name}
                        <small>Watershed boundary available</small>
                      </Link>
                    </td>
                    <td>
                      <span className="code-chip">{watershed.code}</span>
                    </td>
                    <td>
                      {watershed.district}, {watershed.state}
                    </td>
                    <td>{watershed.areaSqKm} km²</td>
                    <td>{watershed.villages}</td>
                    <td>
                      <span className="status-pill status-green">
                        {watershed.status}
                      </span>
                    </td>
                    <td>
                      <Link
                        to={`/watersheds/${watershed.id}`}
                        className="icon-button small-icon"
                        aria-label={`Open ${watershed.name}`}
                      >
                        <ArrowRight size={15} />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="table-footnote">
            Illustrative boundary data shown in GeoJSON-compatible WGS84 coordinates.
          </div>
        </section>
      )}

      {section === "watershed-detail" && activeWatershed && (
        <>
          <section className="detail-hero panel">
            <div className="detail-hero-icon">
              <Waves size={23} />
            </div>
            <div className="detail-hero-copy">
              <span className="code-chip">{activeWatershed.code}</span>
              <h2>{activeWatershed.name}</h2>
              <p>
                {activeWatershed.district}, {activeWatershed.state} ·{" "}
                {activeWatershed.villages} villages
              </p>
            </div>
            <span className="status-pill status-green">
              {activeWatershed.status}
            </span>
            <Link to="/map" className="button button-primary">
              View on map <ArrowRight size={15} />
            </Link>
          </section>
          <div className="metric-grid detail-metrics">
            <Metric
              label="Catchment area"
              value={`${activeWatershed.areaSqKm} km²`}
              icon={Waves}
            />
            <Metric
              label="Mapped assets"
              value={String(assets.length)}
              icon={Layers3}
            />
            <Metric
              label="Verified assets"
              value={String(
                assets.filter((asset) => asset.status === "Verified").length,
              )}
              icon={ShieldCheck}
            />
            <Metric
              label="Villages covered"
              value={String(activeWatershed.villages)}
              icon={MapPinIcon}
            />
          </div>
          <AssetTable
            assets={assets}
            observations={scopedObservations}
            watersheds={watersheds}
            canVerify={
              data.currentUser.data?.role === "GIS Analyst" ||
              data.currentUser.data?.role === "Administrator"
            }
            onVerify={verifyAsset}
          />
          <WatershedSatellitePanel watershedId={activeWatershed.id} />
        </>
      )}

      {section === "evidence" && (
        <section className="panel workspace-table-panel">
          <div className="table-toolbar evidence-toolbar">
            <label className="table-search">
              <Search size={16} />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search assets, villages, notes..."
              />
            </label>
            <label className="table-select">
              <Filter size={14} />
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value)}
              >
                <option>All statuses</option>
                <option>Verified</option>
                <option>Pending review</option>
                <option>Flagged</option>
              </select>
              <ChevronDown size={13} />
            </label>
            <label className="table-select">
              <Layers3 size={14} />
              <select
                value={assetTypeFilter}
                onChange={(event) => setAssetTypeFilter(event.target.value)}
              >
                <option>All types</option>
                <option>Check dam</option>
                <option>Farm pond</option>
                <option>Plantation</option>
                <option>Percolation tank</option>
              </select>
              <ChevronDown size={13} />
            </label>
          </div>
          <AssetTable
            assets={filteredAssets}
            observations={scopedObservations}
            watersheds={watersheds}
            canVerify={
              data.currentUser.data?.role === "GIS Analyst" ||
              data.currentUser.data?.role === "Administrator"
            }
            onVerify={verifyAsset}
          />
        </section>
      )}

      {section === "layers" && (
        <>
          <div className="layers-intro demo-banner">
            <span className="demo-symbol">i</span>
            <span>
              <strong>SIMULATED THEMATIC LAYERS</strong>
              <span>
                {" "}
                NDVI and NDWI overlays in this workspace are illustrative
                sample data, not environmental findings.
              </span>
            </span>
            <Link to="/map">
              Open map <ArrowRight size={14} />
            </Link>
          </div>
          <div className="thematic-grid">
            {thematicLayers.map((layer) => {
              const presentation = Object.entries(layerPresentation).find(
                ([id]) => id === layer.id,
              )?.[1] ?? { icon: Layers3, tint: "blue" }
              const Icon = presentation.icon
              const layerKey = getMapLayerKey(layer.id)
              const isVisible = layerKey
                ? (context?.visibleLayers[layerKey] ?? layer.visibleByDefault)
                : layer.visibleByDefault

              return (
                <article className="panel thematic-card" key={layer.id}>
                  <div className={`thematic-icon ${presentation.tint}`}>
                    <Icon size={20} />
                  </div>
                  <div className="thematic-card-head">
                    <span className="section-kicker">{layer.group}</span>
                    <label className="switch">
                      <input
                        type="checkbox"
                        checked={isVisible}
                        disabled={!layerKey}
                        aria-label={`Toggle ${layer.name} on the map`}
                        onChange={() => {
                          if (layerKey) {
                            context?.setVisibleLayers((state) => ({
                              ...state,
                              [layerKey]: !state[layerKey],
                            }))
                          }
                        }}
                      />
                      <span />
                    </label>
                  </div>
                  <h3>{layer.name}</h3>
                  <p>{layer.description}</p>
                  <div className="thematic-card-foot">
                    <span>{layer.detail}</span>
                    <span>{layer.dateLabel}</span>
                  </div>
                  <button
                    className="thematic-details"
                    onClick={() =>
                      setSelectedLayer(
                        selectedLayer === layer.id ? undefined : layer.id,
                      )
                    }
                  >
                    {selectedLayer === layer.id
                      ? "Hide details"
                      : "Layer details"}{" "}
                    <ChevronDown size={14} />
                  </button>
                  {selectedLayer === layer.id && (
                    <div className="thematic-detail-box">
                      Layer ID: <code>{layer.id}</code>
                      <br />
                      Rendering: MapLibre spatial overlay
                      <br />
                      Source status:{" "}
                      {layer.demo ? "Illustrative sample" : "API data"}
                    </div>
                  )}
                </article>
              )
            })}
            {!thematicLayers.length && (
              <div className="empty-state">
                <Layers3 size={22} />
                <strong>No thematic layers available</strong>
                <span>Layer data may still be loading or unavailable.</span>
              </div>
            )}
          </div>
        </>
      )}

      {section === "analytics" && (
        <>
          <div className="analysis-callout">
            <div className="analysis-callout-icon">
              <Activity size={20} />
            </div>
            <div>
              <strong>Analysis queue</strong>
              <p>
                Analysis jobs simulate a processing lifecycle. Connect a backend
                and satellite provider before using results operationally.
              </p>
            </div>
            <button
              className="button button-secondary"
              disabled={busy}
              onClick={() => void makeAnalysis("NDVI")}
            >
              <Leaf size={15} /> Run NDVI
            </button>
            <button
              className="button button-primary"
              disabled={busy}
              onClick={() => void makeAnalysis("NDWI")}
            >
              <Waves size={15} /> Run NDWI
            </button>
          </div>
          <div className="analysis-grid">
            <section className="panel analysis-summary">
              <div className="section-kicker">
                <span className="kicker-dot green-dot" /> LATEST SAMPLE INDICES
              </div>
              <h2>Environmental indicators</h2>
              <div className="index-reading">
                <span className="thematic-icon green">
                  <Leaf size={18} />
                </span>
                <div>
                  <strong>
                    {latestIndex("NDVI")?.value.toFixed(2) ?? "—"}{" "}
                    <small>NDVI</small>
                  </strong>
                  <span>Simulated Sep 2026 value</span>
                </div>
                <span className="index-range green-range">Illustrative</span>
              </div>
              <div className="index-reading">
                <span className="thematic-icon cyan">
                  <Waves size={18} />
                </span>
                <div>
                  <strong>
                    {latestIndex("NDWI")?.value.toFixed(2) ?? "—"}{" "}
                    <small>NDWI</small>
                  </strong>
                  <span>Simulated Sep 2026 value</span>
                </div>
                <span className="index-range blue-range">Illustrative</span>
              </div>
              <div className="index-disclaimer">
                These sample figures are not observations or environmental
                claims.
              </div>
            </section>
            <section className="panel jobs-table-panel">
              <div className="panel-header">
                <div>
                  <div className="section-kicker">
                    <span className="kicker-dot purple-dot" /> JOB HISTORY
                  </div>
                  <h2>Analysis jobs</h2>
                  <DemoBadge label="Sample jobs" />
                </div>
                <button
                  className="icon-button small-icon"
                  onClick={() => void data.jobs.refetch()}
                  aria-label="Refresh analysis jobs"
                >
                  <RefreshCw size={15} />
                </button>
              </div>
              <div className="job-history-list">
                {(data.jobs.data ?? []).map((job) => (
                  <div className="job-history-row" key={job.id}>
                    <div className="job-history-icon">
                      <Activity size={16} />
                    </div>
                    <div>
                      <strong>{job.type} analysis</strong>
                      <small>
                        {job.id} · {job.createdAt}
                      </small>
                    </div>
                    <span
                      className={`status-pill ${
                        job.status === "Completed"
                          ? "status-green"
                          : "status-blue"
                      }`}
                    >
                      {job.status}
                    </span>
                    <div className="job-history-progress">
                      <i style={{ width: `${job.progress}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
          <section className="panel analysis-note">
            <CircleHelp size={17} />
            <span>
              <strong>Future analysis pipeline</strong> · DEM hydrology,
              satellite time series, land cover, slope and change detection are
              planned for the FastAPI/Celery/Google Earth Engine integration.
            </span>
          </section>
        </>
      )}

      {section === "interventions" && (
        <section className="panel workspace-table-panel">
          <div className="table-toolbar">
            <div className="table-result-count">
              {visibleInterventions.length} {interventionFilter === "Active" ? "active" : ""} intervention
              {visibleInterventions.length === 1 ? "" : "s"} · {activeWatershed?.name}
            </div>
            <div className="segmented-control" role="group" aria-label="Intervention filter">
              {(["Active", "All"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  className={interventionFilter === option ? "active" : ""}
                  aria-pressed={interventionFilter === option}
                  onClick={() => setInterventionFilter(option)}
                >
                  {option === "Active" ? "In progress" : "All work"}
                </button>
              ))}
            </div>
            <button
              className="button button-primary button-small"
              onClick={() => setShowInterventionForm((visible) => !visible)}
            >
              <Plus size={15} /> Add intervention
            </button>
          </div>
          {showInterventionForm && activeWatershed && (
            <form
              className="intervention-create-form"
              onSubmit={(event) => {
                event.preventDefault()
                void data.createIntervention.mutateAsync({
                  watershedId: activeWatershed.id,
                  name: interventionName,
                  type: interventionType,
                  status: interventionStatus,
                  ...(interventionAssetId ? { assetId: interventionAssetId } : {}),
                  ...(interventionInstalledAt ? { installedAt: interventionInstalledAt } : {}),
                }).then(() => {
                  setShowInterventionForm(false)
                  setInterventionName("")
                  setInterventionType("")
                  setInterventionAssetId("")
                  setInterventionFilter(interventionStatus === "In progress" ? "Active" : "All")
                  context?.notify(
                    interventionStatus === "In progress"
                      ? "Work saved as In progress. NDVI and NDWI analysis has been queued."
                      : "Intervention added.",
                  )
                }).catch((error: unknown) => {
                  context?.notify(error instanceof Error ? error.message : "Could not add intervention.")
                })
              }}
            >
              <label>
                Intervention name
                <input required value={interventionName} onChange={(event) => setInterventionName(event.target.value)} />
              </label>
              <label>
                Type
                <input required value={interventionType} onChange={(event) => setInterventionType(event.target.value)} />
              </label>
              <label>
                Field node
                <select value={interventionAssetId} onChange={(event) => setInterventionAssetId(event.target.value)}>
                  <option value="">Whole watershed</option>
                  {assets.map((asset) => (
                    <option key={asset.id} value={asset.id}>{asset.name} · {asset.type}</option>
                  ))}
                </select>
              </label>
              <label>
                Status
                <select value={interventionStatus} onChange={(event) => setInterventionStatus(event.target.value as Intervention["status"])}>
                  <option>Planned</option>
                  <option>In progress</option>
                  <option>Completed</option>
                </select>
              </label>
              <label>
                Installation date{interventionStatus === "Completed" ? " (required)" : ""}
                <input
                  type="date"
                  required={interventionStatus === "Completed"}
                  value={interventionInstalledAt}
                  onChange={(event) => setInterventionInstalledAt(event.target.value)}
                />
              </label>
              <button className="button button-primary button-small" type="submit" disabled={data.createIntervention.isPending}>
                Save intervention
              </button>
            </form>
          )}
          <div className="intervention-grid">
            {visibleInterventions.map((item) => (
              <InterventionCard
                key={item.id}
                item={item}
                assetName={assets.find(({ id }) => id === item.assetId)?.name}
                canEdit={canEditInterventions}
                busy={data.updateIntervention.isPending || data.refreshInterventionIndices.isPending}
                onStart={(entry) => void startIntervention(entry)}
                onRefresh={(entry) => void refreshInterventionIndices(entry)}
              />
            ))}
          </div>
          {!visibleInterventions.length && (
            <div className="empty-state">
              <Activity size={22} />
              <strong>
                {interventionFilter === "Active"
                  ? "No active watershed development work"
                  : "No interventions recorded"}
              </strong>
              <span>
                Save work as <b>In progress</b> to track it here with NDVI and NDWI from satellite imagery.
              </span>
            </div>
          )}
        </section>
      )}

      {section === "reports" && (
        <div className="page-stack">
          <section className="panel workspace-table-panel">
            <div className="table-toolbar">
              <div>
                <strong className="panel-toolbar-title">Report library</strong>
                <span className="table-result-count">{(data.reports.data ?? []).length} reports</span>
              </div>
              <button
                className="button button-primary button-small"
                disabled={busy || !activeWatershed}
                onClick={() => void makeReport()}
              >
                <Plus size={15} /> Generate report
              </button>
            </div>
            <div className="data-table-wrap">
              <table className="data-table">
                <thead><tr><th>REPORT</th><th>TYPE</th><th>CREATED</th><th>STATUS</th></tr></thead>
                <tbody>
                  {(data.reports.data ?? []).map((report) => (
                    <tr key={report.id}>
                      <td><span className="report-file-icon"><FileBarChart2 size={17} /></span><span className="report-name">{report.name}</span></td>
                      <td>{report.type}</td>
                      <td>{report.createdAt}</td>
                      <td><span className="status-pill status-green">{report.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
          {generatedReport && (
            <section className="panel watershed-report-result">
              <div className="table-toolbar">
                <div>
                  <strong className="panel-toolbar-title">Validated report · {generatedReport.factSet.subject}</strong>
                  <span className="table-result-count">Saved {new Date(generatedReport.createdAt).toLocaleString()}</span>
                </div>
                <button
                  className="icon-button small-icon"
                  aria-label="Download saved watershed report PDF"
                  title="Download saved report PDF"
                  onClick={() => exportWatershedReport(generatedReport)}
                ><Download size={15} /></button>
              </div>
              <section className="watershed-report-gaps" aria-labelledby="report-gaps-title">
                <h2 id="report-gaps-title">Data gaps</h2>
                <ul>{generatedReport.gaps.map((item) => <li key={item.code}>{item.text}</li>)}</ul>
              </section>
              <div className="watershed-report-claims">
                <h2>Claims</h2>
                {generatedReport.claims.claims.map((claim, index) => (
                  <article key={`${index}-${claim.factIds.join("-")}`}>
                    <p>{claim.text}</p>
                    <div className="citation-list">
                      {claim.factIds.map((factId) => {
                        const fact = generatedReport.factSet.facts.find((item) => item.id === factId)
                        if (!fact) return null
                        return (
                          <button
                            key={factId}
                            className="citation-chip"
                            type="button"
                            onClick={() => setExpandedFactId(expandedFactId === factId ? undefined : factId)}
                            aria-expanded={expandedFactId === factId}
                          >
                            {fact.label} · {fact.status}
                          </button>
                        )
                      })}
                    </div>
                    {claim.factIds.map((factId) => {
                      if (expandedFactId !== factId) return null
                      const fact = generatedReport.factSet.facts.find((item) => item.id === factId)
                      return fact ? (
                        <div className="citation-records" key={factId}>
                          <strong>{fact.label}</strong>
                          <span>{fact.recordIds.length ? fact.recordIds.join(", ") : "No source records"}</span>
                        </div>
                      ) : null
                    })}
                  </article>
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      {section === "administration" && (
        <div className="settings-grid">
          <section className="panel settings-panel">
            <div className="section-kicker">
              <span className="kicker-dot blue-dot" /> WORKSPACE ACCESS
            </div>
            <h2>Field team</h2>
            <p>Sample roster and role-based access preview.</p>
            <div className="team-list">
              {(data.teamMembers.data ?? []).map((member) => (
                <div className="team-row" key={member.id}>
                  <span className="avatar">{member.initials}</span>
                  <span>
                    <strong>{member.name}</strong>
                    <small>
                      {member.role} · {member.area}
                    </small>
                  </span>
                  <span className="member-active">
                    <i /> {member.status}
                  </span>
                </div>
              ))}
            </div>
            <button
              className="button button-secondary"
              onClick={() =>
                context?.notify(
                  "Invite flow is prepared for the future identity provider.",
                )
              }
            >
              <Plus size={15} /> Invite team member
            </button>
          </section>
          <section className="panel settings-panel">
            <div className="section-kicker">
              <span className="kicker-dot amber-dot" /> AUDIT READINESS
            </div>
            <h2>Verification controls</h2>
            <p>
              Field submissions are captured with verification state and audit
              history.
            </p>
            <div className="admin-check">
              <ShieldCheck size={17} />
              <div>
                <strong>Officer review enabled</strong>
                <small>New submissions start as pending review.</small>
              </div>
              <Check size={16} />
            </div>
            <div className="admin-check">
              <Flag size={17} />
              <div>
                <strong>Flagged evidence status</strong>
                <small>Flagged assets remain visible for follow-up.</small>
              </div>
              <Check size={16} />
            </div>
            <div className="admin-disclaimer">
              Authentication, staff management and audit persistence require
              backend integration.
            </div>
          </section>
        </div>
      )}

      {section === "settings" && (
        <div className="settings-grid">
          <section className="panel settings-panel">
            <div className="section-kicker">
              <span className="kicker-dot blue-dot" /> DATA CONNECTION
            </div>
            <h2>API configuration</h2>
            <p>Frontend connection status for future FastAPI services.</p>
            <div className="setting-line">
              <span>
                <strong>Mode</strong>
                <small>Data source for this workspace</small>
              </span>
              <span className="status-pill status-amber">SAMPLE · MOCK API</span>
            </div>
            <div className="setting-line">
              <span>
                <strong>API endpoint</strong>
                <small>VITE_API_BASE_URL</small>
              </span>
              <code>
                {import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000"}
              </code>
            </div>
            <div className="setting-line">
              <span>
                <strong>Mock API</strong>
                <small>VITE_USE_MOCK_API</small>
              </span>
              <code>{import.meta.env.VITE_USE_MOCK_API ?? "true"}</code>
            </div>
            <button
              className="button button-secondary"
              onClick={() =>
                context?.notify(
                  "Configure VITE_API_BASE_URL and VITE_USE_MOCK_API in your local environment.",
                )
              }
            >
              <Settings2 size={15} /> Configure environment
            </button>
          </section>
          <section className="panel settings-panel">
            <div className="section-kicker">
              <span className="kicker-dot green-dot" /> OFFLINE FIELDWORK
            </div>
            <h2>Local data</h2>
            <p>
              Field evidence is stored in this browser while offline mode is
              being prepared.
            </p>
            <div className="offline-status-card">
              <div>
                <ArrowDownToLine size={18} />
              </div>
              <span>
                <strong>IndexedDB draft storage</strong>
                <small>
                  Field observation images and metadata can be stored on this
                  device.
                </small>
              </span>
              <span className="status-pill status-green">READY</span>
            </div>
            <div className="offline-status-card">
              <div>
                <RefreshCw size={18} />
              </div>
              <span>
                <strong>Background sync</strong>
                <small>
                  Automatic sync requires a configured API connection.
                </small>
              </span>
              <span className="status-pill status-amber">FUTURE</span>
            </div>
            <button
              className="button button-secondary"
              onClick={() =>
                context?.notify(
                  "Offline drafts are retained in this browser. Sync activates when the API is configured.",
                )
              }
            >
              <RefreshCw size={15} /> Check sync status
            </button>
          </section>
        </div>
      )}
    </div>
  )
}

function exportWatershedReport(report: SavedWatershedReport) {
  const pdf = new jsPDF({ unit: "mm", format: "a4" })
  const pageHeight = pdf.internal.pageSize.getHeight()
  const lines = pdf.splitTextToSize(report.renderedMarkdown, 180)
  let y = 15
  pdf.setFont("helvetica", "normal")
  pdf.setFontSize(9)
  for (const line of lines) {
    if (y > pageHeight - 15) {
      pdf.addPage()
      y = 15
    }
    pdf.text(line, 15, y)
    y += 5
  }
  pdf.save(`watershed-report-${report.id}.pdf`)
}

function AssetTable({
  assets,
  observations,
  watersheds,
  canVerify,
  onVerify,
}: {
  assets: Asset[]
  observations: FieldObservation[]
  watersheds: Watershed[]
  /** Only GIS Analysts and Administrators may verify (role preview). */
  canVerify: boolean
  onVerify: (asset: Asset) => void
}) {
  const [activeAsset, setActiveAsset] = useState<Asset>()
  const [flagged, setFlagged] = useState<string[]>([])
  return (
    <div className="data-table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>ASSET</th>
            <th>LOCATION</th>
            <th>COORDINATES</th>
            <th>LAST INSPECTED</th>
            <th>STATUS</th>
            <th>ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          {assets.map((asset) => {
            const isFlagged =
              flagged.includes(asset.id) || asset.status === "Flagged"
            return (
              <tr key={asset.id}>
                <td>
                  <button
                    className="table-asset-link"
                    onClick={() =>
                      setActiveAsset(
                        activeAsset?.id === asset.id ? undefined : asset,
                      )
                    }
                  >
                    <span className="table-asset-icon">
                      <FileImage size={16} />
                    </span>
                    <span>
                      <strong>{asset.name}</strong>
                      <small>{asset.type}</small>
                    </span>
                  </button>
                </td>
                <td>
                  {asset.village}
                  <small className="table-subline">{asset.description}</small>
                </td>
                <td className="coordinate-cell">
                  {asset.location.coordinates[1].toFixed(5)},{" "}
                  {asset.location.coordinates[0].toFixed(5)}
                </td>
                <td>{asset.lastInspected}</td>
                <td>
                  <span
                    className={`status-pill ${
                      isFlagged
                        ? "status-red"
                        : asset.status === "Verified"
                          ? "status-green"
                          : "status-amber"
                    }`}
                  >
                    {isFlagged ? "Flagged" : asset.status}
                  </span>
                </td>
                <td>
                  <div className="table-actions">
                    <button
                      title="View evidence"
                      onClick={() =>
                        setActiveAsset(
                          activeAsset?.id === asset.id ? undefined : asset,
                        )
                      }
                    >
                      <FileImage size={14} />
                    </button>
                    {canVerify && asset.status !== "Verified" && !isFlagged && (
                      <button
                        title="Verify submission"
                        onClick={() => onVerify(asset)}
                      >
                        <ShieldCheck size={14} />
                      </button>
                    )}
                    <button
                      title={isFlagged ? "Remove flag" : "Flag asset"}
                      onClick={() =>
                        setFlagged((previous) =>
                          isFlagged
                            ? previous.filter((id) => id !== asset.id)
                            : [...previous, asset.id],
                        )
                      }
                    >
                      <Flag size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      {activeAsset && (
        <div className="asset-evidence-preview">
          <span className="asset-detail-icon">
            <FileImage size={17} />
          </span>
          <span>
            <strong>{activeAsset.name}</strong>
            <small>
              {activeAsset.description} · Location source:{" "}
              {activeAsset.location.source}
            </small>
          </span>
          <button
            className="icon-button small-icon"
            onClick={() => setActiveAsset(undefined)}
            aria-label="Close evidence preview"
          >
            <X size={15} />
          </button>
        </div>
      )}
      {activeAsset &&
        (() => {
          // An observation either created this asset (same id) or was linked to
          // it later; show the most recent one for the asset.
          const observation = observations
            .filter((item) => item.id === activeAsset.id || item.assetId === activeAsset.id)
            .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
            .at(-1)
          if (!observation) return null
          return (
            <div className="hs-evidence-detail">
              {observation.imageDataUrl && (
                <img src={observation.imageDataUrl} alt="Field evidence" />
              )}
              <TrustPanel
                trust={observation.trust}
                imageHash={observation.imageSha256}
                snapDistanceMeters={observation.snapDistanceMeters}
                location={observation.location}
                watershedName={
                  watersheds.find(({ id }) => id === observation.watershedId)
                    ?.name
                }
                watershedIsDemo={
                  watersheds.find(({ id }) => id === observation.watershedId)
                    ?.demo
                }
                photoContentConfirmed={
                  observation.photoContentReview?.status ===
                  "officer-confirmed"
                }
              />
              <div className="hs-audit">
                <strong>Audit trail</strong>
                <ul>
                  {observation.auditHistory.map((entry, index) => (
                    <li key={index}>
                      <small>{entry.timestamp.slice(0, 19).replace("T", " ")}</small>{" "}
                      {entry.action} · {entry.actor}
                    </li>
                  ))}
                </ul>
                <button
                  className="button button-secondary button-small"
                  onClick={() => downloadObservationAudit(observation)}
                >
                  Download audit record (JSON)
                </button>
              </div>
            </div>
          )
        })()}
      {!assets.length && (
        <div className="empty-state">
          <FileImage size={22} />
          <strong>No field evidence matches</strong>
          <span>Try a different search or add a field observation.</span>
          <Link to="/upload" className="button button-primary button-small">
            Add observation
          </Link>
        </div>
      )}
      <div className="table-footnote">
        Coordinates are WGS84 longitude / latitude on the API and shown as
        latitude, longitude here. Sample assets are illustrative data.
      </div>
    </div>
  )
}

function Metric({
  label,
  value,
  icon: Icon,
}: {
  label: string
  value: string
  icon: typeof Waves
}) {
  return (
    <div className="metric-card detail-metric">
      <div className="metric-card-top">
        <span>{label}</span>
        <span className="metric-icon blue">
          <Icon size={16} />
        </span>
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-caption">Sample watershed data</div>
    </div>
  )
}

function getMapLayerKey(id: string): MapLayerKey | undefined {
  return mapLayerKeys.find((key) => key === id)
}
