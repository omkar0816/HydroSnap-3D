import { useEffect, useMemo, useState } from "react"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { Activity, Layers3, Play } from "lucide-react"
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { hydrosnapService } from "@/services/hydrosnapService"
import {
  useAnalysisJob,
  useSatelliteRasterImage,
  useSatelliteRasters,
  useWatershedSatellite,
} from "@/hooks/useWatershedSatellite"
import type { SatelliteMeasurementRow } from "@/types/evidence"
import {
  baselineFor,
  calculateIndexChange,
  defaultDateRange,
  formatIndex,
  gradientCss,
  INDEX_STYLES,
  type IndexType,
} from "@/utils/satelliteStyles"

/** What the map needs to draw one rendered index composite. */
export type SatelliteOverlay = {
  url: string
  /** [west, south, east, north] in WGS84 degrees. */
  bounds: [number, number, number, number]
  indexType: IndexType
  opacity: number
  windowStart: string
  windowEnd: string
}

type Props = {
  watershedId: string
  /** When provided (map page) the panel can publish the selected index as a map overlay. */
  onOverlayChange?: (overlay: SatelliteOverlay | null) => void
}

const STATUS_LABEL: Record<string, string> = {
  submitting: "Submitting analysis job…",
  queued: "Queued — waiting for the satellite worker",
  running: "Running — retrieving Sentinel-2 imagery from Earth Engine",
  done: "Completed",
  failed: "Failed",
}

/** Watershed-level rows only (asset-buffer rows belong to interventions). */
function watershedRows(rows: SatelliteMeasurementRow[], index: IndexType) {
  return rows.filter((row) => row.indexType === index && row.assetId === null)
}

export function WatershedSatellitePanel({ watershedId, onOverlayChange }: Props) {
  const queryClient = useQueryClient()
  const satelliteQuery = useWatershedSatellite(watershedId)
  const rastersQuery = useSatelliteRasters(watershedId)
  const [jobId, setJobId] = useState<string>()
  const [indexType, setIndexType] = useState<IndexType>("NDVI")
  const [range, setRange] = useState(() => defaultDateRange())
  const [showOverlay, setShowOverlay] = useState(false)
  const [overlayRole, setOverlayRole] = useState<"current" | "baseline">("current")
  const [opacity, setOpacity] = useState(0.8)
  const jobQuery = useAnalysisJob(jobId)

  const today = new Date().toISOString().slice(0, 10)
  const rangeError =
    !range.start || !range.end ? "Choose a start and end date."
    : range.end < range.start ? "The end date must not precede the start date."
    : range.end > today ? "The end date cannot be in the future."
    : Date.parse(range.end) - Date.parse(range.start) > 365 * 86_400_000 ? "Choose a range of one year or less."
    : null
  const baseline = rangeError ? null : baselineFor(range.start, range.end)

  const createJob = useMutation({
    mutationFn: () => {
      if (!baseline) throw new Error(rangeError ?? "Invalid date range.")
      return hydrosnapService.createAnalysis(watershedId, indexType, {
        baselineWindow: baseline,
        currentWindow: { start: range.start, end: range.end },
      })
    },
    onSuccess: (job) => setJobId(job.id),
  })

  useEffect(() => {
    if (jobQuery.data?.status === "done") {
      void queryClient.invalidateQueries({ queryKey: ["watershed-satellite", watershedId] })
      void queryClient.invalidateQueries({ queryKey: ["watershed-satellite-rasters", watershedId] })
    }
  }, [jobQuery.data?.status, queryClient, watershedId])

  const rows = useMemo(() => satelliteQuery.data ?? [], [satelliteQuery.data])
  const indexRows = watershedRows(rows, indexType)
  const chartData = indexRows
    .filter((row) => row.status === "measured" && row.mean !== null)
    .map((row) => ({ date: row.windowEnd, mean: row.mean, role: row.windowRole }))
    .sort((a, b) => a.date.localeCompare(b.date))

  // Statistics shown: the latest finished job's baseline + current rows.
  const latestJobId = [...indexRows].sort((a, b) => a.computedAt.localeCompare(b.computedAt)).at(-1)?.jobId
  const latestRows = indexRows
    .filter((row) => row.jobId === latestJobId)
    .sort((a, b) => a.windowRole.localeCompare(b.windowRole))
  const { change, changePct } = calculateIndexChange(latestRows, indexType)

  const jobStatus = jobQuery.data?.status ?? (createJob.isPending ? "submitting" : null)
  const busy = createJob.isPending || jobStatus === "queued" || jobStatus === "running"

  // Raster for the selected index/role (watershed level), drawn on the map.
  const raster = (rastersQuery.data ?? []).find(
    (item) => item.assetId === null && item.indexType === indexType && item.windowRole === overlayRole,
  )
  const imageQuery = useSatelliteRasterImage(showOverlay && onOverlayChange ? raster?.id : undefined)
  useEffect(() => {
    if (!onOverlayChange) return
    if (showOverlay && raster && imageQuery.data) {
      onOverlayChange({
        url: imageQuery.data,
        bounds: raster.bounds,
        indexType,
        opacity,
        windowStart: raster.windowStart,
        windowEnd: raster.windowEnd,
      })
    } else {
      onOverlayChange(null)
    }
  }, [onOverlayChange, showOverlay, raster, imageQuery.data, indexType, opacity])
  useEffect(() => () => onOverlayChange?.(null), [onOverlayChange])

  const style = INDEX_STYLES[indexType]

  return (
    <section className="panel satellite-analysis-panel">
      <div className="table-toolbar">
        <div>
          <div className="section-kicker"><span className="kicker-dot blue-dot" /> SATELLITE INTELLIGENCE</div>
          <h2>Sentinel-2 {indexType} analysis</h2>
          <p>
            Measured from Sentinel-2 imagery through Google Earth Engine. Window differences are descriptive only;
            they are not an impact estimate.
          </p>
        </div>
      </div>

      <div className="satellite-controls">
        <label>
          Index
          <select value={indexType} onChange={(event) => setIndexType(event.target.value as IndexType)}>
            <option value="NDVI">NDVI — vegetation</option>
            <option value="NDWI">NDWI — surface water</option>
          </select>
        </label>
        <label>
          Start date
          <input type="date" max={today} value={range.start}
            onChange={(event) => setRange((value) => ({ ...value, start: event.target.value }))} />
        </label>
        <label>
          End date
          <input type="date" max={today} value={range.end}
            onChange={(event) => setRange((value) => ({ ...value, end: event.target.value }))} />
        </label>
        <button
          className="button button-primary"
          disabled={busy || Boolean(rangeError)}
          onClick={() => createJob.mutate()}
        >
          <Play size={14} /> Run analysis
        </button>
      </div>
      <div className="satellite-baseline-note">
        {rangeError
          ? <span role="alert">{rangeError}</span>
          : `Compared with the same dates a year earlier: ${baseline?.start} to ${baseline?.end}.`}
      </div>

      {jobStatus && (
        <div className={`satellite-job-status ${jobStatus === "failed" ? "status-red" : "status-blue"}`} role="status">
          {STATUS_LABEL[jobStatus] ?? `Job ${jobStatus}`}
          {jobQuery.data?.attempts ? ` · attempt ${jobQuery.data.attempts}` : ""}
          {jobQuery.data?.error ? ` · ${jobQuery.data.error}` : ""}
        </div>
      )}
      {createJob.error && <p role="alert">{createJob.error.message}</p>}

      {latestRows.length ? (
        <table className="satellite-stats" aria-label={`${indexType} statistics`}>
          <thead>
            <tr>
              <th>Window</th><th>Mean</th><th>Median</th><th>P10</th><th>P90</th><th>Std</th><th>Valid px</th><th>Scenes</th>
            </tr>
          </thead>
          <tbody>
            {latestRows.map((row) => (
              <tr key={row.id}>
                <td>
                  <strong>{row.windowRole}</strong>
                  <br /><small>{row.windowStart} → {row.windowEnd}</small>
                </td>
                {row.status === "measured" ? (
                  <>
                    <td>{formatIndex(row.mean)}</td>
                    <td>{formatIndex(row.median)}</td>
                    <td>{formatIndex(row.p10)}</td>
                    <td>{formatIndex(row.p90)}</td>
                    <td>{formatIndex(row.std)}</td>
                  </>
                ) : (
                  <td colSpan={5}>Insufficient cloud-free data; no value reported</td>
                )}
                <td>{row.validPixelPct === null ? "—" : `${row.validPixelPct.toFixed(1)}%`}</td>
                <td>{row.sceneCount ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="satellite-empty-state">
          <Activity size={19} />
          <span>No {indexType} measurement yet. Choose a date range and run the analysis.</span>
        </div>
      )}

      <div className="satellite-comparison-summary">
        <strong>
          {change === null
            ? "Difference between windows unavailable"
            : `Difference between windows: ${change > 0 ? "+" : ""}${change.toFixed(3)} ${indexType}${changePct === null ? "" : ` (${changePct > 0 ? "+" : ""}${changePct.toFixed(1)}%)`}`}
        </strong>
        <span>Computed from measured baseline/current windows with at least 60% valid pixels.</span>
        {latestRows[0]?.attribution && <span>{latestRows[0].attribution} · {latestRows[0].source}</span>}
      </div>

      {chartData.length > 1 && (
        <div className="satellite-chart" role="img" aria-label={`${indexType} mean by satellite window`}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 12, right: 16, bottom: 4, left: 4 }}>
              <CartesianGrid strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="date" tickLine={false} />
              <YAxis domain={[-1, 1]} tickLine={false} />
              <Tooltip formatter={(value) => [Number(value).toFixed(3), `${indexType} mean`]} />
              <Line type="monotone" dataKey="mean" stroke="#2f8d6e" strokeWidth={2} dot={{ r: 4 }} connectNulls={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {onOverlayChange && (
        <div className="satellite-overlay-controls">
          <div className="row">
            <label>
              <input type="checkbox" checked={showOverlay} disabled={!raster}
                onChange={(event) => setShowOverlay(event.target.checked)} />{" "}
              <Layers3 size={12} /> Show {indexType} on map
            </label>
            <label>
              Window{" "}
              <select value={overlayRole} onChange={(event) => setOverlayRole(event.target.value as "current" | "baseline")}>
                <option value="current">Current</option>
                <option value="baseline">Baseline</option>
              </select>
            </label>
            <label>
              Opacity{" "}
              <input type="range" min={0.2} max={1} step={0.05} value={opacity}
                onChange={(event) => setOpacity(Number(event.target.value))} />
            </label>
          </div>
          {!raster && <small>No rendered {indexType} image yet — run an analysis first.</small>}
          {showOverlay && imageQuery.isLoading && <small>Loading image…</small>}
          {imageQuery.error && <small role="alert">{imageQuery.error.message}</small>}
          <div className="satellite-legend">
            <div className="satellite-legend-bar" style={{ background: gradientCss(indexType) }} />
            <div className="satellite-legend-scale">
              <span>{style.min}</span><span>{style.hint}</span><span>{style.max}</span>
            </div>
          </div>
        </div>
      )}
      {satelliteQuery.error && <p role="alert">{satelliteQuery.error.message}</p>}
    </section>
  )
}
