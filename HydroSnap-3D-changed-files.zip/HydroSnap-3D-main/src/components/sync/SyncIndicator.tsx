import { useEffect, useRef, useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { CloudOff, CloudUpload, LoaderCircle, RefreshCw } from "lucide-react"
import { env } from "@/config/env"
import { startAutoSync, subscribeSync, syncNow } from "@/services/syncService"
import type { QueuedObservation } from "@/types/domain"

/** Topbar sync status + manual "Sync now". Starts auto-sync on mount. */
export function SyncIndicator() {
  const queryClient = useQueryClient()
  const wasSyncing = useRef(false)
  const [records, setRecords] = useState<QueuedObservation[]>([])
  const [syncing, setSyncing] = useState(false)
  const [syncError, setSyncError] = useState<string>()
  const [online, setOnline] = useState(
    typeof navigator === "undefined" ? true : navigator.onLine,
  )
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const unsubscribe = subscribeSync((next, isSyncing) => {
      setRecords(next)
      setSyncing(isSyncing)
      // A sync run just finished (including one started by "Save observation"):
      // reload what the Field evidence page and the map display.
      if (wasSyncing.current && !isSyncing) {
        void queryClient.invalidateQueries({ queryKey: ["assets"] })
        void queryClient.invalidateQueries({ queryKey: ["observations"] })
        void queryClient.invalidateQueries({ queryKey: ["watershed-evidence"] })
      }
      wasSyncing.current = isSyncing
    })
    const stop = startAutoSync(() => {
      void queryClient.invalidateQueries({ queryKey: ["assets"] })
      void queryClient.invalidateQueries({ queryKey: ["observations"] })
      // Field evidence and the map read this per-watershed bundle.
      void queryClient.invalidateQueries({ queryKey: ["watershed-evidence"] })
    }, setSyncError)
    const update = () => setOnline(navigator.onLine)
    window.addEventListener("online", update)
    window.addEventListener("offline", update)
    return () => {
      unsubscribe()
      stop()
      window.removeEventListener("online", update)
      window.removeEventListener("offline", update)
    }
  }, [queryClient])

  const pending = records.filter((r) => r.syncStatus === "pending").length
  const failed = records.filter((r) => r.syncStatus === "failed").length
  const rejected = records.filter((r) => r.syncStatus === "rejected").length
  const synced = records.filter((r) => r.syncStatus === "synced").length
  const waiting = pending + failed

  const label = !online
    ? `Offline · ${waiting} queued`
    : syncing
      ? "Syncing…"
      : syncError
        ? "Sync unavailable"
        : rejected
          ? `${rejected} rejected`
        : waiting
          ? `${waiting} to sync`
          : "All synced"

  return (
    <div className="popover-anchor topbar-sync">
      <button
        className={`hs-sync-button ${
          !online ? "offline" : waiting || syncError ? "waiting" : ""
        }`}
        onClick={() => setOpen((value) => !value)}
        aria-label="Sync status"
      >
        {!online ? (
          <CloudOff size={15} />
        ) : syncing ? (
          <LoaderCircle size={15} className="spin" />
        ) : (
          <CloudUpload size={15} />
        )}
        <span>{label}</span>
      </button>
      {open && (
        <div className="popover hs-sync-popover">
          <div className="popover-title">Field sync</div>
          {syncError && (
            <p className="hs-muted" role="alert">
              Could not access the offline queue: {syncError}
            </p>
          )}
          <p>{pending} pending · {failed} failed · {rejected} rejected · {synced} synced</p>
          {records
            .filter((r) => r.syncStatus === "failed" || r.syncStatus === "rejected")
            .slice(0, 3)
            .map((r) => (
              <p key={r.id} className="hs-muted" role={r.syncStatus === "rejected" ? "alert" : undefined}>
                {r.observation.assetType}: {r.syncStatus === "rejected" ? "Rejected by server" : "Upload failed"}: {r.lastError}
                {r.syncStatus === "failed" && ` (retry ${r.nextAttemptAt
                  ? new Date(r.nextAttemptAt).toLocaleTimeString()
                  : "soon"})`}
              </p>
            ))}
          {env.useMockApi && (
            <p className="hs-muted">
              Sample mode: records sync to the in-browser preview service only,
              not a server.
            </p>
          )}
          <button
            className="text-button"
            disabled={!online || syncing}
            onClick={() => {
              void syncNow(true)
                .then(() => {
                  setSyncError(undefined)
                  void queryClient.invalidateQueries({ queryKey: ["assets"] })
                  void queryClient.invalidateQueries({
                    queryKey: ["observations"],
                  })
                  void queryClient.invalidateQueries({
                    queryKey: ["watershed-evidence"],
                  })
                })
                .catch((error: unknown) => {
                  setSyncError(
                    error instanceof Error
                      ? error.message
                      : "Could not sync offline records.",
                  )
                })
            }}
          >
            <RefreshCw size={13} /> Sync now
          </button>
        </div>
      )}
    </div>
  )
}

export default SyncIndicator
