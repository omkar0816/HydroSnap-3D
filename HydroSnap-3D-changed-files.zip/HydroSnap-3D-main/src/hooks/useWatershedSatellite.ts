import { useQuery } from "@tanstack/react-query"
import { hydrosnapService } from "@/services/hydrosnapService"
import { env } from "@/config/env"

export function useWatershedSatellite(watershedId?: string) {
  return useQuery({
    queryKey: ["watershed-satellite", watershedId],
    queryFn: () => {
      if (!watershedId) throw new Error("A watershed is required.")
      return hydrosnapService.getSatelliteMeasurements(watershedId)
    },
    enabled: Boolean(watershedId),
    staleTime: 30_000,
  })
}

export function useAnalysisJob(jobId?: string) {
  return useQuery({
    queryKey: ["analysis-job", jobId],
    queryFn: () => {
      if (!jobId) throw new Error("An analysis job is required.")
      return hydrosnapService.getAnalysisJob(jobId)
    },
    enabled: Boolean(jobId),
    refetchInterval: (query) => {
      if (env.useMockApi) return false
      const status = query.state.data?.status
      return status === "queued" || status === "running" ? 2_000 : false
    },
    retry: false,
  })
}

export function useSatelliteRasters(watershedId?: string) {
  return useQuery({
    queryKey: ["watershed-satellite-rasters", watershedId],
    queryFn: () => {
      if (!watershedId) throw new Error("A watershed is required.")
      return hydrosnapService.getSatelliteRasters(watershedId)
    },
    enabled: Boolean(watershedId),
    staleTime: 30_000,
  })
}

export function useSatelliteRasterImage(rasterId?: string) {
  return useQuery({
    queryKey: ["satellite-raster-image", rasterId],
    queryFn: () => {
      if (!rasterId) throw new Error("A raster is required.")
      return hydrosnapService.getSatelliteRasterImageUrl(rasterId)
    },
    enabled: Boolean(rasterId),
    staleTime: Number.POSITIVE_INFINITY,
    gcTime: 10 * 60_000,
    retry: false,
  })
}
