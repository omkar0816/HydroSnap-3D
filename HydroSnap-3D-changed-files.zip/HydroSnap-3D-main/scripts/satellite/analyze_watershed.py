"""Compute Sentinel-2 NDVI/NDWI statistics inside a PostGIS watershed AOI.

Two interchangeable backends are available:

* ``earthengine`` (default): Google Earth Engine, COPERNICUS/S2_SR_HARMONIZED.
  Statistics are reduced server-side and a rendered PNG of the index composite
  can be returned for the map overlay.
* ``stac``: Element84 Earth Search via odc-stac (offline-friendly fallback).

Select with ``SATELLITE_BACKEND=earthengine|stac``.
"""

from __future__ import annotations

import json
import os
import argparse
import urllib.request
from datetime import date, timedelta

import numpy as np
import psycopg
from pyproj import CRS, Transformer
from shapely.geometry import mapping, shape
from shapely.ops import transform as transform_geometry

CATALOG = "https://earth-search.aws.element84.com/v1"
SOURCE = "Copernicus Sentinel-2 L2A via Element84 Earth Search"
EE_SOURCE = "Copernicus Sentinel-2 L2A (COPERNICUS/S2_SR_HARMONIZED) via Google Earth Engine"
EE_COLLECTION = "COPERNICUS/S2_SR_HARMONIZED"
ATTRIBUTION = "Contains modified Copernicus Sentinel data"
SOURCE_LICENCE = "Copernicus Sentinel data terms of use"
CLOUD_COVER_LIMIT = int(os.environ.get("CLOUD_COVER_LIMIT", "30"))
CLEAR_SCL_CLASSES = (4, 5, 6)
MIN_VALID_PIXEL_PCT = 60.0
MAX_SCENES = 100
RASTER_DIMENSION = int(os.environ.get("SATELLITE_RASTER_PX", "768"))

# Display ranges / palettes for the map overlay (ColorBrewer-style ramps).
RASTER_STYLES = {
    "NDVI": {
        "min": -0.1,
        "max": 0.9,
        "palette": ["a6611a", "dfc27d", "f5f5b8", "a6d96a", "1a9641", "00441b"],
    },
    "NDWI": {
        "min": -0.6,
        "max": 0.6,
        "palette": ["8c510a", "d8b365", "f6e8c3", "c7eae5", "5ab4ac", "01665e"],
    },
}


def clear_scl_mask(scl: np.ndarray) -> np.ndarray:
    return np.isin(scl, CLEAR_SCL_CLASSES)


def ndvi_ndwi(green: np.ndarray, red: np.ndarray, nir: np.ndarray, index: str):
    if index == "NDVI":
        denominator = nir + red
        valid = (red >= 0) & (nir >= 0) & (denominator > 1e-6)
        numerator = nir - red
    elif index == "NDWI":
        denominator = green + nir
        valid = (green >= 0) & (nir >= 0) & (denominator > 1e-6)
        numerator = green - nir
    else:
        raise ValueError("index must be NDVI or NDWI")
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(valid, numerator / denominator, np.nan)


def summarize_aoi(values: np.ndarray, aoi_mask: np.ndarray) -> dict[str, float | int | None]:
    total = int(aoi_mask.sum())
    valid = np.isfinite(values) & aoi_mask
    selected = values[valid]
    valid_pct = 100.0 * selected.size / total if total else 0.0
    if not selected.size:
        return {
            "mean": None,
            "median": None,
            "p10": None,
            "p90": None,
            "std": None,
            "valid_pixel_pct": valid_pct,
        }
    return {
        "mean": float(np.mean(selected)),
        "median": float(np.median(selected)),
        "p10": float(np.percentile(selected, 10)),
        "p90": float(np.percentile(selected, 90)),
        "std": float(np.std(selected)),
        "valid_pixel_pct": valid_pct,
    }


def _load_aoi(connection, watershed_id: str, asset_id: str | None, buffer_m: int | None):
    row = connection.execute(
        "SELECT ST_AsGeoJSON(boundary) FROM watersheds WHERE id = %s",
        (watershed_id,),
    ).fetchone()
    if not row:
        raise ValueError(f"Unknown watershed: {watershed_id}")
    boundary_value = json.loads(row[0]) if isinstance(row[0], str) else row[0]
    boundary = shape(boundary_value)
    if asset_id:
        asset = connection.execute(
            "SELECT ST_AsGeoJSON(location) FROM assets WHERE id = %s AND watershed_id = %s",
            (asset_id, watershed_id),
        ).fetchone()
        if not asset:
            raise ValueError("Asset does not belong to the requested watershed.")
        if not buffer_m or buffer_m <= 0:
            raise ValueError("Asset analyses require a positive buffer_m.")
        point_value = json.loads(asset[0]) if isinstance(asset[0], str) else asset[0]
        point = shape(point_value)
        center_lon, center_lat = point.x, point.y
        zone = int((center_lon + 180) // 6) + 1
        epsg = (32600 if center_lat >= 0 else 32700) + zone
        to_meters = Transformer.from_crs("EPSG:4326", f"EPSG:{epsg}", always_xy=True).transform
        to_wgs84 = Transformer.from_crs(f"EPSG:{epsg}", "EPSG:4326", always_xy=True).transform
        buffered = transform_geometry(to_meters, point).buffer(buffer_m)
        boundary_projected = transform_geometry(to_meters, boundary)
        clipped = buffered.intersection(boundary_projected)
        return transform_geometry(to_wgs84, clipped), CRS.from_epsg(epsg)

    centroid = boundary.centroid
    zone = int((centroid.x + 180) // 6) + 1
    epsg = (32600 if centroid.y >= 0 else 32700) + zone
    return boundary, CRS.from_epsg(epsg)


def _validate_request(window_start: str, window_end: str, index: str) -> None:
    if date.fromisoformat(window_end) < date.fromisoformat(window_start):
        raise ValueError("window end must not precede window start")
    if index not in ("NDVI", "NDWI"):
        raise ValueError("index must be NDVI or NDWI")


def _database_url(database_url: str | None) -> str:
    connection_string = database_url or os.environ.get("DATABASE_URL")
    if not connection_string:
        raise ValueError("DATABASE_URL must be set")
    return connection_string


def _load_projected_aoi(
    watershed_id: str,
    asset_id: str | None,
    buffer_m: int | None,
    database_url: str | None,
):
    with psycopg.connect(_database_url(database_url)) as connection:
        aoi_wgs84, crs = _load_aoi(connection, watershed_id, asset_id, buffer_m)
    if aoi_wgs84.is_empty or not aoi_wgs84.is_valid:
        raise ValueError("Watershed AOI geometry is empty or invalid")
    return aoi_wgs84, crs


def analyze_watershed(
    watershed_id: str,
    window_start: str,
    window_end: str,
    index: str,
    asset_id: str | None = None,
    buffer_m: int | None = None,
    database_url: str | None = None,
    include_raster: bool = False,
    backend: str | None = None,
) -> dict:
    """Return NDVI/NDWI statistics for one window.

    With ``include_raster`` (Earth Engine backend only) the result also carries a
    ``raster`` entry: ``{"png": bytes, "bounds": [w, s, e, n], "vmin", "vmax"}``.
    """
    _validate_request(window_start, window_end, index)
    selected = (backend or os.environ.get("SATELLITE_BACKEND", "earthengine")).lower()
    if selected not in ("earthengine", "stac"):
        raise ValueError("SATELLITE_BACKEND must be 'earthengine' or 'stac'")
    aoi_wgs84, crs = _load_projected_aoi(watershed_id, asset_id, buffer_m, database_url)
    if selected == "earthengine":
        return _analyze_earth_engine(
            aoi_wgs84, watershed_id, window_start, window_end, index,
            asset_id, buffer_m, include_raster,
        )
    return _analyze_stac(
        aoi_wgs84, crs, watershed_id, window_start, window_end, index,
        asset_id, buffer_m,
    )


# --------------------------------------------------------------------------
# Google Earth Engine backend
# --------------------------------------------------------------------------

_EE_READY = False


def init_earth_engine() -> None:
    """Initialise Earth Engine once per process.

    Credentials, in order of precedence:
      1. EE_SERVICE_ACCOUNT + EE_PRIVATE_KEY_JSON (key file contents)
      2. EE_SERVICE_ACCOUNT + EE_PRIVATE_KEY_FILE (path to key file)
      3. Stored user credentials from ``earthengine authenticate``
    EE_PROJECT (a Google Cloud project registered for Earth Engine) is required.
    """
    global _EE_READY
    if _EE_READY:
        return
    try:
        import ee
    except ImportError as error:  # pragma: no cover - depends on deployment
        raise RuntimeError(
            "earthengine-api is not installed. Run: pip install -r scripts/satellite/requirements.txt"
        ) from error
    project = os.environ.get("EE_PROJECT")
    if not project:
        raise RuntimeError("EE_PROJECT must be set to a Google Cloud project enabled for Earth Engine")
    account = os.environ.get("EE_SERVICE_ACCOUNT")
    key_json = os.environ.get("EE_PRIVATE_KEY_JSON")
    key_file = os.environ.get("EE_PRIVATE_KEY_FILE")
    if account and (key_json or key_file):
        if key_json:
            credentials = ee.ServiceAccountCredentials(account, key_data=key_json)
        else:
            credentials = ee.ServiceAccountCredentials(account, key_file=key_file)
        ee.Initialize(credentials, project=project)
    else:
        ee.Initialize(project=project)
    _EE_READY = True


def _ee_index_image(image, index: str):
    """Mask clouds with SCL (classes 4/5/6) and compute NDVI or NDWI (reflectance 0..1)."""
    import ee

    scl = image.select("SCL")
    clear = scl.eq(4).Or(scl.eq(5)).Or(scl.eq(6))
    if index == "NDVI":
        pair = ["B8", "B4"]  # (NIR - Red) / (NIR + Red)
    else:
        pair = ["B3", "B8"]  # (Green - NIR) / (Green + NIR), McFeeters 1996
    reflectance = image.select(pair).divide(10000)
    non_negative = reflectance.reduce(ee.Reducer.min()).gte(0)
    denominator = reflectance.reduce(ee.Reducer.sum()).gt(1e-6)
    value = reflectance.normalizedDifference(pair).rename(index)
    return value.updateMask(clear).updateMask(non_negative).updateMask(denominator)


def _ee_collection(geometry, window_start: str, window_end: str):
    import ee

    end_exclusive = (date.fromisoformat(window_end) + timedelta(days=1)).isoformat()
    return (
        ee.ImageCollection(EE_COLLECTION)
        .filterBounds(geometry)
        .filterDate(window_start, end_exclusive)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", CLOUD_COVER_LIMIT))
        .sort("CLOUDY_PIXEL_PERCENTAGE")
        .limit(MAX_SCENES)
    )


def _ee_stats_reducer():
    import ee

    return (
        ee.Reducer.mean()
        .combine(ee.Reducer.median(), sharedInputs=True)
        .combine(ee.Reducer.percentile([10, 90]), sharedInputs=True)
        .combine(ee.Reducer.stdDev(), sharedInputs=True)
        .combine(ee.Reducer.count(), sharedInputs=True)
    )


def _ee_render_png(composite, geometry, bounds: list[float], index: str) -> dict:
    """Render the composite (transparent outside the AOI) to a PNG for the map."""
    import ee

    style = RASTER_STYLES[index]
    visual = composite.clip(geometry).visualize(
        min=style["min"], max=style["max"], palette=style["palette"]
    )
    west, south, east, north = bounds
    url = visual.getThumbURL({
        "region": ee.Geometry.Rectangle([west, south, east, north], "EPSG:4326", False),
        "dimensions": RASTER_DIMENSION,
        "crs": "EPSG:4326",
        "format": "png",
    })
    with urllib.request.urlopen(url, timeout=180) as response:  # nosec B310 - EE-issued https URL
        png = response.read()
    return {"png": png, "bounds": bounds, "vmin": style["min"], "vmax": style["max"]}


def _analyze_earth_engine(
    aoi_wgs84,
    watershed_id: str,
    window_start: str,
    window_end: str,
    index: str,
    asset_id: str | None,
    buffer_m: int | None,
    include_raster: bool,
) -> dict:
    import ee

    init_earth_engine()
    simplified = aoi_wgs84.simplify(0.00005, preserve_topology=True)
    if simplified.is_empty:
        simplified = aoi_wgs84
    geometry = ee.Geometry(mapping(simplified), "EPSG:4326", False)

    collection = _ee_collection(geometry, window_start, window_end)
    scene_ids = collection.aggregate_array("system:index").getInfo() or []
    if not scene_ids:
        return _empty_result(
            watershed_id, asset_id, buffer_m, index, window_start, window_end, ee_backend=True,
        )

    composite = collection.map(lambda image: _ee_index_image(image, index)).median().rename(index)
    reducer = _ee_stats_reducer()
    reduce_args = dict(
        geometry=geometry, scale=10, maxPixels=1e10, bestEffort=True, tileScale=4,
    )
    stats = composite.reduceRegion(reducer=reducer, **reduce_args).getInfo() or {}
    total = (
        ee.Image.constant(1).rename("total")
        .reduceRegion(reducer=ee.Reducer.count(), **reduce_args)
        .getInfo() or {}
    )
    total_pixels = float(total.get("total") or 0)
    valid_pixels = float(stats.get(f"{index}_count") or 0)
    valid_pct = min(100.0, 100.0 * valid_pixels / total_pixels) if total_pixels else 0.0

    def stat(name: str):
        value = stats.get(f"{index}_{name}")
        return None if value is None else float(value)

    statistics = {
        "mean": stat("mean"),
        "median": stat("median"),
        "p10": stat("p10"),
        "p90": stat("p90"),
        "std": stat("stdDev"),
        "valid_pixel_pct": valid_pct,
    }
    status = "measured" if valid_pct >= MIN_VALID_PIXEL_PCT and statistics["mean"] is not None else "insufficient_data"
    if status != "measured":
        for key in ("mean", "median", "p10", "p90", "std"):
            statistics[key] = None

    result = {
        **statistics,
        "status": status,
        "scene_count": len(scene_ids),
        "scene_ids": [str(identifier) for identifier in scene_ids],
        "source": EE_SOURCE,
        "source_licence": SOURCE_LICENCE,
        "attribution": ATTRIBUTION,
        "method": (
            f"Sentinel-2 L2A median composite (Earth Engine, cloud < {CLOUD_COVER_LIMIT}%); "
            "SCL classes 4, 5, 6; per-AOI statistics at 10 m"
        ),
        "resolution_m": 10,
        "aoi_scope": "asset_buffer" if asset_id else "watershed",
        "buffer_m": buffer_m,
        "watershed_id": watershed_id,
        "asset_id": asset_id,
        "index_type": index,
        "window_start": window_start,
        "window_end": window_end,
    }
    if include_raster and status == "measured":
        bounds = [float(value) for value in simplified.bounds]
        result["raster"] = _ee_render_png(composite, geometry, bounds, index)
    return result


# --------------------------------------------------------------------------
# STAC (Element84) backend
# --------------------------------------------------------------------------

def _analyze_stac(
    aoi_wgs84,
    crs,
    watershed_id: str,
    window_start: str,
    window_end: str,
    index: str,
    asset_id: str | None,
    buffer_m: int | None,
) -> dict:
    import odc.stac
    from pystac_client import Client
    from rasterio.features import geometry_mask

    from scripts.compute_indices.compute_indices import validate_scene_metadata

    to_projected = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform
    to_wgs84 = Transformer.from_crs(crs, "EPSG:4326", always_xy=True).transform
    aoi = transform_geometry(to_projected, aoi_wgs84)
    if aoi.is_empty or not aoi.is_valid:
        raise ValueError("Watershed AOI geometry is empty or invalid")
    bounds = aoi.bounds
    search_aoi = transform_geometry(to_wgs84, aoi)
    client = Client.open(CATALOG)
    items = list(client.search(
        collections=["sentinel-2-l2a"],
        bbox=list(search_aoi.bounds),
        datetime=f"{window_start}/{window_end}",
        query={"eo:cloud_cover": {"lt": CLOUD_COVER_LIMIT}},
        max_items=MAX_SCENES,
    ).items())
    if not items:
        return _empty_result(watershed_id, asset_id, buffer_m, index, window_start, window_end)

    transforms = validate_scene_metadata(items)
    dataset = odc.stac.load(
        items,
        bands=["green", "red", "nir", "scl"],
        bbox=list(bounds),
        crs=crs,
        resolution=10,
        groupby="solar_day",
        dtype="float32",
    )
    x_values = dataset.x.values
    y_values = dataset.y.values
    affine = dataset.odc.geobox.transform
    aoi_mask = geometry_mask(
        [mapping(aoi)],
        out_shape=(len(y_values), len(x_values)),
        transform=affine,
        invert=True,
    )
    clear = dataset.scl.isin(CLEAR_SCL_CLASSES)
    scaled: dict[str, object] = {}
    for band in ("green", "red", "nir"):
        scale, offset = transforms[band]
        scaled[band] = dataset[band].where(clear).astype("float32") * scale + offset
    band_green = scaled["green"]
    band_red = scaled["red"]
    band_nir = scaled["nir"]
    if index == "NDVI":
        denominator = band_nir + band_red
        values = ((band_nir - band_red) / denominator).where(
            (band_red >= 0) & (band_nir >= 0) & (denominator > 1e-6)
        )
    else:
        denominator = band_green + band_nir
        values = ((band_green - band_nir) / denominator).where(
            (band_green >= 0) & (band_nir >= 0) & (denominator > 1e-6)
        )
    composite = values.median("time", skipna=True).values
    statistics = summarize_aoi(composite, aoi_mask)
    status = "measured" if statistics["valid_pixel_pct"] >= MIN_VALID_PIXEL_PCT else "insufficient_data"
    if status != "measured":
        for key in ("mean", "median", "p10", "p90", "std"):
            statistics[key] = None
    return {
        **statistics,
        "status": status,
        "scene_count": len(items),
        "scene_ids": [item.id for item in items],
        "source": SOURCE,
        "source_licence": SOURCE_LICENCE,
        "attribution": ATTRIBUTION,
        "method": "Sentinel-2 L2A median composite; SCL classes 4, 5, 6; per-AOI statistics",
        "resolution_m": 10,
        "aoi_scope": "asset_buffer" if asset_id else "watershed",
        "buffer_m": buffer_m,
        "watershed_id": watershed_id,
        "asset_id": asset_id,
        "index_type": index,
        "window_start": window_start,
        "window_end": window_end,
    }


def _empty_result(watershed_id, asset_id, buffer_m, index, window_start, window_end, ee_backend=False):
    return {
        "mean": None,
        "median": None,
        "p10": None,
        "p90": None,
        "std": None,
        "valid_pixel_pct": 0.0,
        "status": "insufficient_data",
        "scene_count": 0,
        "scene_ids": [],
        "source": EE_SOURCE if ee_backend else SOURCE,
        "source_licence": SOURCE_LICENCE,
        "attribution": ATTRIBUTION,
        "method": "Sentinel-2 L2A median composite; SCL classes 4, 5, 6; per-AOI statistics",
        "resolution_m": 10,
        "aoi_scope": "asset_buffer" if asset_id else "watershed",
        "buffer_m": buffer_m,
        "watershed_id": watershed_id,
        "asset_id": asset_id,
        "index_type": index,
        "window_start": window_start,
        "window_end": window_end,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--watershed-id", required=True)
    parser.add_argument("--window-start", required=True)
    parser.add_argument("--window-end", required=True)
    parser.add_argument("--index", choices=("NDVI", "NDWI"), required=True)
    parser.add_argument("--asset-id")
    parser.add_argument("--buffer-m", type=int)
    parser.add_argument("--backend", choices=("earthengine", "stac"))
    args = parser.parse_args()
    result = analyze_watershed(
        watershed_id=args.watershed_id,
        window_start=args.window_start,
        window_end=args.window_end,
        index=args.index,
        asset_id=args.asset_id,
        buffer_m=args.buffer_m,
        backend=args.backend,
    )
    result.pop("raster", None)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
