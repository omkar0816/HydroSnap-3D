import type { AuthError, Session } from "@supabase/supabase-js"
import { z } from "zod"
import {
  isSupabaseConfigured,
  supabase,
  TABLES,
  type OfficerRow,
} from "@/lib/supabase"
import type { User } from "@/types/domain"

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface OfficerProfile {
  id: string
  officerCode: string
  name: string
  email: string
  department: string
  locationOperatingOn: string
  state: string
  district: string
  status: "active" | "suspended"
}

/** A message that is safe to show the person as-is. */
export class AuthFlowError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "AuthFlowError"
  }
}

/**
 * - not-officer: signed in, but no row in `officers` (e.g. a government account)
 * - suspended:   officer row exists but government suspended it
 * - unavailable: could not reach the database (offline, outage)
 */
export class OfficerLookupError extends Error {
  constructor(
    message: string,
    public readonly kind: "not-officer" | "suspended" | "unavailable",
  ) {
    super(message)
    this.name = "OfficerLookupError"
  }
}

/* ------------------------------------------------------------------ */
/* Validation                                                          */
/* ------------------------------------------------------------------ */

export const INDIAN_STATES_AND_UTS = [
  "Andaman and Nicobar Islands",
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chandigarh",
  "Chhattisgarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu and Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Ladakh",
  "Lakshadweep",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Puducherry",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
] as const

const collapse = (value: string) => value.replace(/\s+/g, " ").trim()

const requiredText = (label: string, min: number, max: number) =>
  z
    .string()
    .transform(collapse)
    .pipe(
      z
        .string()
        .min(1, `${label} is required.`)
        .min(min, `${label} must be at least ${min} characters.`)
        .max(max, `${label} must be at most ${max} characters.`),
    )

const emailField = z
  .string()
  .transform((value) => value.trim().toLowerCase())
  .pipe(
    z
      .string()
      .min(1, "Email is required.")
      .pipe(z.email("Enter a valid email address.")),
  )

// Letters in any script (Devanagari included), spaces, dots, apostrophes, hyphens.
const personName = requiredText("Full name", 2, 100).pipe(
  z
    .string()
    .regex(
      /^[\p{L}\p{M}][\p{L}\p{M} .'’-]*$/u,
      "Name can contain letters, spaces, dots, apostrophes and hyphens only.",
    ),
)

export const loginSchema = z.object({
  email: emailField,
  password: z.string().min(1, "Password is required."),
})

export const officerSignUpSchema = z
  .object({
    name: personName,
    department: requiredText("Department", 2, 120),
    email: emailField,
    state: z.enum(INDIAN_STATES_AND_UTS, "Select your state."),
    district: requiredText("District", 2, 60),
    locationOperatingOn: requiredText("Location operating on", 2, 160),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters.")
      .max(72, "Password must be at most 72 characters.")
      .refine((value) => /[A-Za-z]/.test(value) && /\d/.test(value), {
        message: "Password needs at least one letter and one number.",
      }),
    confirmPassword: z.string(),
  })
  .refine((value) => value.password === value.confirmPassword, {
    path: ["confirmPassword"],
    message: "Passwords do not match.",
  })

export type LoginInput = z.input<typeof loginSchema>
export type OfficerSignUpInput = z.input<typeof officerSignUpSchema>

/** Maps zod issues to { fieldName: firstMessage } for inline form errors. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const result: Record<string, string> = {}
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form")
    if (!(key in result)) result[key] = issue.message
  }
  return result
}

/* ------------------------------------------------------------------ */
/* Officer profile (+ small offline cache for field use)               */
/* ------------------------------------------------------------------ */

const PROFILE_CACHE_KEY = "hydrosnap.officer-profile"

function rowToProfile(row: OfficerRow): OfficerProfile {
  return {
    id: row.id,
    officerCode: row.officer_code,
    name: row.name,
    email: row.email,
    department: row.department,
    locationOperatingOn: row.location_operating_on,
    state: row.state,
    district: row.district,
    status: row.status,
  }
}

function readCachedProfile(userId: string): OfficerProfile | null {
  try {
    const raw = window.localStorage.getItem(PROFILE_CACHE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as OfficerProfile
    return parsed.id === userId ? parsed : null
  } catch {
    return null
  }
}

function writeCachedProfile(profile: OfficerProfile): void {
  try {
    window.localStorage.setItem(PROFILE_CACHE_KEY, JSON.stringify(profile))
  } catch {
    // Storage full or blocked; the cache is only an offline convenience.
  }
}

function clearCachedProfile(): void {
  try {
    window.localStorage.removeItem(PROFILE_CACHE_KEY)
  } catch {
    // ignore
  }
}

/**
 * Loads the officer row for a signed-in user.
 * - Row missing  → not an officer account (never falls back to the cache).
 * - Suspended    → blocked.
 * - DB unreachable → falls back to the cached profile of the SAME user so a
 *   field officer can still open the offline app; otherwise "unavailable".
 */
export async function fetchOfficerProfile(
  userId: string,
): Promise<OfficerProfile> {
  const { data, error } = await supabase
    .from(TABLES.officers)
    .select("*")
    .eq("id", userId)
    .maybeSingle<OfficerRow>()

  if (error) {
    const cached = readCachedProfile(userId)
    if (cached && cached.status === "active") return cached
    throw new OfficerLookupError(
      "Could not load your officer profile. Check your connection and try again.",
      "unavailable",
    )
  }
  if (!data) {
    throw new OfficerLookupError(
      "This account is not registered as a field officer. Government accounts use the government login.",
      "not-officer",
    )
  }
  const profile = rowToProfile(data)
  if (profile.status === "suspended") {
    clearCachedProfile()
    throw new OfficerLookupError(
      "This officer account has been suspended. Contact your department administrator.",
      "suspended",
    )
  }
  writeCachedProfile(profile)
  return profile
}

export function officerToUser(profile: OfficerProfile): User {
  const initials = profile.name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("")
  return {
    id: profile.id,
    name: profile.name,
    email: profile.email,
    role: "Field Officer",
    initials: initials || "FO",
    officerCode: profile.officerCode,
    department: profile.department,
    locationOperatingOn: profile.locationOperatingOn,
    state: profile.state,
    district: profile.district,
  }
}

/* ------------------------------------------------------------------ */
/* Auth actions                                                        */
/* ------------------------------------------------------------------ */

function friendlyAuthError(error: AuthError): string {
  const message = error.message.toLowerCase()
  if (message.includes("invalid login credentials")) {
    return "Email or password is incorrect."
  }
  if (message.includes("email not confirmed")) {
    return "Confirm your email first. Check your inbox for the confirmation link."
  }
  if (message.includes("already registered") || message.includes("already been registered")) {
    return "An account with this email already exists. Log in instead."
  }
  if (error.status === 429 || message.includes("rate limit")) {
    return "Too many attempts. Wait a minute and try again."
  }
  if (message.includes("database error saving new user")) {
    return "Could not create the officer profile. Check your details and try again."
  }
  if (message.includes("fetch") || message.includes("network")) {
    return "No internet connection. Signing in or signing up needs a connection."
  }
  return error.message
}

function assertConfigured(): void {
  if (!isSupabaseConfigured) {
    throw new AuthFlowError(
      "Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.local and restart the dev server.",
    )
  }
}

export async function signInWithEmail(input: LoginInput): Promise<void> {
  assertConfigured()
  const { email, password } = loginSchema.parse(input)
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw new AuthFlowError(friendlyAuthError(error))
}

export interface SignUpResult {
  /** True when Supabase "Confirm email" is on and no session exists yet. */
  needsEmailConfirmation: boolean
}

export async function signUpOfficer(
  input: OfficerSignUpInput,
): Promise<SignUpResult> {
  assertConfigured()
  const values = officerSignUpSchema.parse(input)
  const { data, error } = await supabase.auth.signUp({
    email: values.email,
    password: values.password,
    options: {
      emailRedirectTo: `${window.location.origin}/login`,
      // Read by the `handle_new_auth_user` trigger to create the officers row.
      data: {
        role: "officer",
        name: values.name,
        department: values.department,
        location_operating_on: values.locationOperatingOn,
        state: values.state,
        district: values.district,
      },
    },
  })
  if (error) throw new AuthFlowError(friendlyAuthError(error))
  // With email confirmation on, an existing email returns a fake user with no identities.
  if (data.user && (data.user.identities?.length ?? 0) === 0) {
    throw new AuthFlowError(
      "An account with this email already exists. Log in instead.",
    )
  }
  return { needsEmailConfirmation: !data.session }
}

export async function signOut(): Promise<void> {
  clearCachedProfile()
  const { error } = await supabase.auth.signOut()
  if (error) {
    // Offline: the server call failed, so remove the stored session ourselves.
    try {
      for (const key of Object.keys(window.localStorage)) {
        if (key.startsWith("sb-") && key.endsWith("-auth-token")) {
          window.localStorage.removeItem(key)
        }
      }
    } catch {
      // ignore
    }
    await supabase.auth.signOut({ scope: "local" }).catch(() => undefined)
  }
}

export async function getSession(): Promise<Session | null> {
  const { data } = await supabase.auth.getSession()
  return data.session
}

/** For the service layer: the signed-in officer as a domain User. */
export async function getCurrentOfficerUser(): Promise<User> {
  const session = await getSession()
  if (!session) throw new AuthFlowError("You are not signed in.")
  return officerToUser(await fetchOfficerProfile(session.user.id))
}
