import { createClient } from "@supabase/supabase-js"
import { env } from "@/config/env"

/**
 * Supabase client + typed table definitions for HydroSnap-3D.
 *
 * The tables themselves are created by `supabase/schema.sql` (run it once in
 * the Supabase SQL editor); a browser client cannot create tables. The types
 * below mirror that file so every query is checked at compile time.
 *
 * Access control is enforced by Row Level Security in the database, not by
 * this file or the React route guard.
 */

export type VerificationStatus = "Verified" | "Pending review" | "Flagged"
export type AssetType =
  | "Check dam"
  | "Farm pond"
  | "Plantation"
  | "Percolation tank"

export interface OfficerRow {
  id: string
  officer_code: string
  name: string
  email: string
  department: string
  location_operating_on: string
  state: string
  district: string
  status: "active" | "suspended"
  created_at: string
  updated_at: string
}

export interface GovernmentAdminRow {
  id: string
  government_code: string
  name: string
  email: string
  location_working: string
  created_at: string
}

export interface FieldObservationRow {
  id: string
  officer_id: string
  watershed_id: string
  asset_id: string | null
  asset_type: AssetType
  village: string
  description: string
  inspection_date: string
  lat: number
  lng: number
  gps_accuracy_m: number | null
  location_source: "exif" | "device" | "manual" | "demo" | "snapped"
  image_path: string | null
  image_sha256: string | null
  verification_status: VerificationStatus
  trust: unknown | null
  audit_history: unknown[]
  idempotency_key: string | null
  payload: Record<string, unknown>
  sent_to_government_at: string | null
  created_at: string
  updated_at: string
}

export interface AssetRow {
  id: string
  officer_id: string
  watershed_id: string
  name: string
  type: AssetType
  village: string
  description: string
  lat: number
  lng: number
  status: VerificationStatus
  installed_at: string | null
  last_inspected: string | null
  sent_to_government_at: string | null
  created_at: string
  updated_at: string
}

export interface InterventionRow {
  id: string
  officer_id: string
  watershed_id: string
  name: string
  type: string
  village: string
  status: "Planned" | "In progress" | "Completed"
  progress: number
  budget: number
  due_date: string | null
  sent_to_government_at: string | null
  created_at: string
  updated_at: string
}

export interface AiSummaryRow {
  id: string
  officer_id: string
  watershed_id: string | null
  observation_id: string | null
  english: string
  hindi: string | null
  marathi: string | null
  model_name: string | null
  language_review: string
  generated_at: string
  sent_to_government_at: string | null
}

export interface ReportRow {
  id: string
  officer_id: string
  watershed_id: string
  asset_id: string | null
  name: string
  type: "Watershed summary" | "Field inspection" | "Asset registry" | "Analytics"
  status: "Ready" | "Generating"
  file_path: string | null
  sent_to_government_at: string | null
  created_at: string
}

/** Table names, so services never hard-code strings. */
export const TABLES = {
  officers: "officers",
  governmentAdmins: "government_admins",
  fieldObservations: "field_observations",
  assets: "assets",
  interventions: "interventions",
  aiSummaries: "ai_summaries",
  reports: "reports",
} as const

export const PHOTO_BUCKET = "field-photos"

export const isSupabaseConfigured = Boolean(
  env.supabaseUrl && env.supabaseAnonKey,
)

/**
 * Created even when unconfigured (with placeholders) so imports never crash;
 * the login page shows a setup message instead of calling it.
 */
export const supabase = createClient(
  env.supabaseUrl || "http://localhost:54321",
  env.supabaseAnonKey || "missing-anon-key",
  {
    auth: {
      persistSession: true, // officers stay signed in across offline field days
      autoRefreshToken: true,
      detectSessionInUrl: true, // email-confirmation links
    },
  },
)
