import { useEffect, useState, type FormEvent, type ReactNode } from "react"
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  LoaderCircle,
  MapPinned,
  ShieldCheck,
  Waves,
  WifiOff,
} from "lucide-react"
import { Navigate, useLocation } from "react-router-dom"
import { useAuth } from "@/auth/AuthContext"
import { isSupabaseConfigured } from "@/lib/supabase"
import {
  AuthFlowError,
  fieldErrors,
  INDIAN_STATES_AND_UTS,
  loginSchema,
  officerSignUpSchema,
  type LoginInput,
  type OfficerSignUpInput,
} from "@/services/authService"

type Mode = "login" | "signup"
type Errors = Record<string, string>

const emptyLogin: LoginInput = { email: "", password: "" }
const emptySignUp: OfficerSignUpInput = {
  name: "",
  department: "",
  email: "",
  state: "" as OfficerSignUpInput["state"],
  district: "",
  locationOperatingOn: "",
  password: "",
  confirmPassword: "",
}

/** Only allow redirects back into the app, never to another site. */
function safeRedirect(value: unknown): string {
  if (
    typeof value === "string" &&
    value.startsWith("/") &&
    !value.startsWith("//") &&
    !value.startsWith("/login")
  ) {
    return value
  }
  return "/"
}

const inputClass = (invalid: boolean) =>
  `h-10 w-full rounded-lg border bg-white px-3 text-sm text-[#18354f] outline-none transition placeholder:text-[#9aa8b6] focus:border-[#237db5] focus:ring-2 focus:ring-[#237db5]/20 disabled:bg-[#f4f7fa] ${
    invalid ? "border-[#d9534f]" : "border-[#d9e3ec]"
  }`

function Field({
  id,
  label,
  error,
  hint,
  children,
}: {
  id: string
  label: string
  error?: string
  hint?: string
  children: ReactNode
}) {
  return (
    <div className="grid gap-1.5">
      <label htmlFor={id} className="text-xs font-semibold text-[#37526a]">
        {label}
      </label>
      {children}
      {error ? (
        <p id={`${id}-error`} className="m-0 text-xs text-[#c0392b]">
          {error}
        </p>
      ) : hint ? (
        <p className="m-0 text-xs text-[#8493a3]">{hint}</p>
      ) : null}
    </div>
  )
}

export function LoginPage() {
  const { status, notice, clearNotice, signIn, signUp } = useAuth()
  const location = useLocation()
  const redirectTo = safeRedirect(
    (location.state as { from?: string } | null)?.from,
  )

  const [mode, setMode] = useState<Mode>("login")
  const [login, setLogin] = useState<LoginInput>(emptyLogin)
  const [signup, setSignup] = useState<OfficerSignUpInput>(emptySignUp)
  const [errors, setErrors] = useState<Errors>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [confirmationEmail, setConfirmationEmail] = useState<string | null>(null)
  const [offline, setOffline] = useState(
    typeof navigator !== "undefined" && !navigator.onLine,
  )

  useEffect(() => {
    const update = () => setOffline(!navigator.onLine)
    window.addEventListener("online", update)
    window.addEventListener("offline", update)
    return () => {
      window.removeEventListener("online", update)
      window.removeEventListener("offline", update)
    }
  }, [])

  // Already signed in as an officer (or just became one): go to the app.
  if (status === "ready") return <Navigate to={redirectTo} replace />

  const busy = submitting || status === "checking"

  function switchMode(next: Mode) {
    setMode(next)
    setErrors({})
    setFormError(null)
    setConfirmationEmail(null)
    clearNotice()
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    if (busy) return
    setFormError(null)
    clearNotice()

    const schema = mode === "login" ? loginSchema : officerSignUpSchema
    const parsed = schema.safeParse(mode === "login" ? login : signup)
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error))
      return
    }
    setErrors({})

    setSubmitting(true)
    try {
      if (mode === "login") {
        await signIn(login)
        // On success AuthProvider validates the officer row and `status`
        // flips to "ready", which redirects above. A rejection shows as `notice`.
      } else {
        const result = await signUp(signup)
        if (result.needsEmailConfirmation) setConfirmationEmail(signup.email.trim())
      }
    } catch (error) {
      setFormError(
        error instanceof AuthFlowError
          ? error.message
          : "Something went wrong. Please try again.",
      )
    } finally {
      setSubmitting(false)
    }
  }

  const passwordType = showPassword ? "text" : "password"
  const bannerMessage = formError ?? notice
  const setL = (key: keyof LoginInput, value: string) =>
    setLogin((current) => ({ ...current, [key]: value }))
  const setS = (key: keyof OfficerSignUpInput, value: string) =>
    setSignup((current) => ({ ...current, [key]: value }))
  const describe = (id: string) => (errors[id] ? `${id}-error` : undefined)

  return (
    <div className="grid min-h-screen bg-[#f2f7fc] lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      {/* Brand panel */}
      <aside className="hidden flex-col justify-between bg-gradient-to-br from-[#153957] to-[#12334f] p-12 text-white lg:flex">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-[#277fae] to-[#1c5d89]">
            <Waves size={21} />
          </span>
          <span className="font-[Manrope,sans-serif] text-xl font-extrabold tracking-tight">
            HydroSnap <span className="text-[#5fc7a0]">3D</span>
          </span>
        </div>
        <div className="max-w-md">
          <h1 className="m-0 font-[Manrope,sans-serif] text-3xl font-extrabold leading-tight">
            Field evidence for watershed development
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-[#b8cde0]">
            Capture geo-coded photos, check them against watershed boundaries,
            and send officer-confirmed reports to the government dashboard.
          </p>
          <ul className="mt-8 grid list-none gap-4 p-0 text-sm text-[#d6e4f0]">
            <li className="flex items-center gap-3">
              <MapPinned size={18} className="text-[#5fc7a0]" />
              Photos tied to your operating location
            </li>
            <li className="flex items-center gap-3">
              <ShieldCheck size={18} className="text-[#5fc7a0]" />
              Every report carries your officer ID and name
            </li>
          </ul>
        </div>
        <p className="m-0 text-xs text-[#8fb0cc]">SIH 2026 · SIH26015 · Prototype</p>
      </aside>

      {/* Form panel */}
      <main className="flex items-center justify-center p-5 sm:p-8">
        <div className="w-full max-w-md">
          <div className="mb-6 flex items-center gap-2.5 lg:hidden">
            <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-[#277fae] to-[#1c5d89] text-white">
              <Waves size={19} />
            </span>
            <span className="font-[Manrope,sans-serif] text-lg font-extrabold text-[#153957]">
              HydroSnap <span className="text-[#32926d]">3D</span>
            </span>
          </div>

          <div className="rounded-2xl border border-[#e6ebf1] bg-white p-6 shadow-sm sm:p-8">
            <p className="m-0 text-xs font-bold uppercase tracking-widest text-[#8493a3]">
              Field officer
            </p>
            <h2 className="mb-5 mt-1 font-[Manrope,sans-serif] text-2xl font-extrabold text-[#153957]">
              {mode === "login" ? "Log in" : "Create officer account"}
            </h2>

            <div
              role="tablist"
              aria-label="Sign up or log in"
              className="mb-5 grid grid-cols-2 gap-1 rounded-lg bg-[#eef3f8] p-1"
            >
              {(["login", "signup"] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  role="tab"
                  aria-selected={mode === tab}
                  onClick={() => switchMode(tab)}
                  className={`h-8 rounded-md text-sm font-semibold transition ${
                    mode === tab
                      ? "bg-white text-[#153957] shadow-sm"
                      : "text-[#607489] hover:text-[#153957]"
                  }`}
                >
                  {tab === "login" ? "Log in" : "Sign up"}
                </button>
              ))}
            </div>

            {!isSupabaseConfigured && (
              <div
                className="mb-4 flex gap-2.5 rounded-lg border border-[#f2dca8] bg-[#fff8e6] p-3 text-xs text-[#7a5a14]"
                role="alert"
              >
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>
                  Supabase is not configured. Add{" "}
                  <code>VITE_SUPABASE_URL</code> and{" "}
                  <code>VITE_SUPABASE_ANON_KEY</code> to <code>.env.local</code>{" "}
                  and restart <code>pnpm dev</code>.
                </span>
              </div>
            )}

            {offline && (
              <div
                className="mb-4 flex gap-2.5 rounded-lg border border-[#d9e3ec] bg-[#f4f8fb] p-3 text-xs text-[#496175]"
                role="status"
              >
                <WifiOff size={16} className="mt-0.5 shrink-0" />
                <span>
                  You are offline. Signing in needs a connection the first
                  time; after that the app keeps working in the field.
                </span>
              </div>
            )}

            {bannerMessage && (
              <div
                className="mb-4 flex gap-2.5 rounded-lg border border-[#f3c6c2] bg-[#fdf0ef] p-3 text-xs text-[#a1342b]"
                role="alert"
              >
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>{bannerMessage}</span>
              </div>
            )}

            {confirmationEmail ? (
              <div className="text-center" role="status">
                <CheckCircle2 className="mx-auto mb-3 text-[#308661]" size={34} />
                <h3 className="m-0 text-base font-bold text-[#153957]">
                  Check your email
                </h3>
                <p className="mt-2 text-sm text-[#607489]">
                  We sent a confirmation link to{" "}
                  <strong>{confirmationEmail}</strong>. Confirm it, then log in.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const email = confirmationEmail
                    switchMode("login")
                    setL("email", email)
                  }}
                  className="mt-5 h-10 w-full rounded-lg bg-[#237db5] text-sm font-semibold text-white hover:bg-[#1c6a9b]"
                >
                  Go to log in
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="grid gap-4">
                {mode === "signup" && (
                  <>
                    <Field id="name" label="Full name" error={errors.name}>
                      <input
                        id="name"
                        className={inputClass(Boolean(errors.name))}
                        value={signup.name}
                        onChange={(e) => setS("name", e.target.value)}
                        autoComplete="name"
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby={describe("name")}
                        disabled={busy}
                      />
                    </Field>
                    <Field
                      id="department"
                      label="Department"
                      error={errors.department}
                    >
                      <input
                        id="department"
                        className={inputClass(Boolean(errors.department))}
                        value={signup.department}
                        onChange={(e) => setS("department", e.target.value)}
                        placeholder="e.g. Soil & Water Conservation"
                        aria-invalid={Boolean(errors.department)}
                        aria-describedby={describe("department")}
                        disabled={busy}
                      />
                    </Field>
                  </>
                )}

                <Field
                  id="email"
                  label="Email"
                  error={errors.email}
                >
                  <input
                    id="email"
                    type="email"
                    inputMode="email"
                    className={inputClass(Boolean(errors.email))}
                    value={mode === "login" ? login.email : signup.email}
                    onChange={(e) =>
                      mode === "login"
                        ? setL("email", e.target.value)
                        : setS("email", e.target.value)
                    }
                    autoComplete="email"
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={describe("email")}
                    disabled={busy}
                  />
                </Field>

                {mode === "signup" && (
                  <>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field id="state" label="State" error={errors.state}>
                        <select
                          id="state"
                          className={inputClass(Boolean(errors.state))}
                          value={signup.state}
                          onChange={(e) => setS("state", e.target.value)}
                          aria-invalid={Boolean(errors.state)}
                          aria-describedby={describe("state")}
                          disabled={busy}
                        >
                          <option value="">Select state</option>
                          {INDIAN_STATES_AND_UTS.map((state) => (
                            <option key={state} value={state}>
                              {state}
                            </option>
                          ))}
                        </select>
                      </Field>
                      <Field
                        id="district"
                        label="District"
                        error={errors.district}
                      >
                        <input
                          id="district"
                          className={inputClass(Boolean(errors.district))}
                          value={signup.district}
                          onChange={(e) => setS("district", e.target.value)}
                          placeholder="e.g. Pune"
                          aria-invalid={Boolean(errors.district)}
                          aria-describedby={describe("district")}
                          disabled={busy}
                        />
                      </Field>
                    </div>
                    <Field
                      id="locationOperatingOn"
                      label="Location operating on"
                      error={errors.locationOperatingOn}
                      hint="Block, taluka, watershed cluster or village group you cover."
                    >
                      <input
                        id="locationOperatingOn"
                        className={inputClass(Boolean(errors.locationOperatingOn))}
                        value={signup.locationOperatingOn}
                        onChange={(e) =>
                          setS("locationOperatingOn", e.target.value)
                        }
                        placeholder="e.g. Khadakwasla cluster, Haveli"
                        aria-invalid={Boolean(errors.locationOperatingOn)}
                        aria-describedby={describe("locationOperatingOn")}
                        disabled={busy}
                      />
                    </Field>
                  </>
                )}

                <Field
                  id="password"
                  label="Password"
                  error={errors.password}
                  hint={
                    mode === "signup"
                      ? "At least 8 characters with a letter and a number."
                      : undefined
                  }
                >
                  <div className="relative">
                    <input
                      id="password"
                      type={passwordType}
                      className={`${inputClass(Boolean(errors.password))} pr-10`}
                      value={mode === "login" ? login.password : signup.password}
                      onChange={(e) =>
                        mode === "login"
                          ? setL("password", e.target.value)
                          : setS("password", e.target.value)
                      }
                      autoComplete={
                        mode === "login" ? "current-password" : "new-password"
                      }
                      aria-invalid={Boolean(errors.password)}
                      aria-describedby={describe("password")}
                      disabled={busy}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((value) => !value)}
                      className="absolute inset-y-0 right-0 grid w-10 place-items-center text-[#8493a3] hover:text-[#37526a]"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </Field>

                {mode === "signup" && (
                  <Field
                    id="confirmPassword"
                    label="Confirm password"
                    error={errors.confirmPassword}
                  >
                    <input
                      id="confirmPassword"
                      type={passwordType}
                      className={inputClass(Boolean(errors.confirmPassword))}
                      value={signup.confirmPassword}
                      onChange={(e) => setS("confirmPassword", e.target.value)}
                      autoComplete="new-password"
                      aria-invalid={Boolean(errors.confirmPassword)}
                      aria-describedby={describe("confirmPassword")}
                      disabled={busy}
                    />
                  </Field>
                )}

                <button
                  type="submit"
                  disabled={busy || !isSupabaseConfigured}
                  className="mt-1 flex h-11 items-center justify-center gap-2 rounded-lg bg-[#237db5] text-sm font-bold text-white transition hover:bg-[#1c6a9b] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {busy && <LoaderCircle className="spin" size={16} />}
                  {busy
                    ? mode === "login"
                      ? "Signing in…"
                      : "Creating account…"
                    : mode === "login"
                      ? "Log in"
                      : "Create account"}
                </button>
              </form>
            )}
          </div>

          <p className="mt-5 text-center text-xs text-[#8493a3]">
            Government official? The government login is coming soon.
          </p>
        </div>
      </main>
    </div>
  )
}
