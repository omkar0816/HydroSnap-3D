import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react"
import { useQueryClient } from "@tanstack/react-query"
import type { Session } from "@supabase/supabase-js"
import { isSupabaseConfigured, supabase } from "@/lib/supabase"
import {
  fetchOfficerProfile,
  OfficerLookupError,
  signInWithEmail,
  signOut as signOutOfSupabase,
  signUpOfficer,
  type LoginInput,
  type OfficerProfile,
  type OfficerSignUpInput,
  type SignUpResult,
} from "@/services/authService"

/**
 * initializing → reading the stored session
 * signed-out   → no session
 * checking     → session found, loading/validating the officers row
 * ready        → valid, active officer
 * unavailable  → session exists but the profile could not be loaded (offline, outage)
 */
export type AuthStatus =
  | "initializing"
  | "signed-out"
  | "checking"
  | "ready"
  | "unavailable"

interface AuthContextValue {
  status: AuthStatus
  session: Session | null
  officer: OfficerProfile | null
  /** Why the last sign-in was rejected (not an officer, suspended, ...). */
  notice: string | null
  clearNotice: () => void
  signIn: (input: LoginInput) => Promise<void>
  signUp: (input: OfficerSignUpInput) => Promise<SignUpResult>
  signOut: () => Promise<void>
  retry: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient()
  const [session, setSession] = useState<Session | null>(null)
  const [sessionLoaded, setSessionLoaded] = useState(false)
  const [officer, setOfficer] = useState<OfficerProfile | null>(null)
  const [profileFailed, setProfileFailed] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const [attempt, setAttempt] = useState(0)
  const previousUserId = useRef<string | null>(null)

  // 1. Track the Supabase session. The callback only stores the session;
  //    awaiting other Supabase calls inside it can deadlock the auth client.
  useEffect(() => {
    if (!isSupabaseConfigured) {
      setSessionLoaded(true)
      return
    }
    let active = true
    void supabase.auth.getSession().then(({ data }) => {
      if (!active) return
      setSession(data.session)
      setSessionLoaded(true)
    })
    const { data } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next)
      setSessionLoaded(true)
    })
    return () => {
      active = false
      data.subscription.unsubscribe()
    }
  }, [])

  // 2. Whenever the signed-in user changes, validate them as an officer.
  const userId = session?.user.id ?? null
  useEffect(() => {
    if (!sessionLoaded) return

    // Never let one officer's cached data appear for the next person.
    if (previousUserId.current !== userId) {
      if (previousUserId.current !== null) queryClient.clear()
      previousUserId.current = userId
    }

    if (!userId) {
      setOfficer(null)
      setProfileFailed(false)
      return
    }

    let active = true
    setProfileFailed(false)
    fetchOfficerProfile(userId)
      .then((profile) => {
        if (!active) return
        setOfficer(profile)
        setNotice(null)
      })
      .catch((error: unknown) => {
        if (!active) return
        setOfficer(null)
        if (error instanceof OfficerLookupError && error.kind !== "unavailable") {
          // Wrong account type or suspended: reject and sign out.
          setNotice(error.message)
          void signOutOfSupabase()
          return
        }
        setProfileFailed(true)
        setNotice(
          error instanceof Error ? error.message : "Could not load your profile.",
        )
      })
    return () => {
      active = false
    }
  }, [sessionLoaded, userId, attempt, queryClient])

  const status: AuthStatus = !sessionLoaded
    ? "initializing"
    : !userId
      ? "signed-out"
      : officer?.id === userId
        ? "ready"
        : profileFailed
          ? "unavailable"
          : "checking"

  const signIn = useCallback(async (input: LoginInput) => {
    setNotice(null)
    await signInWithEmail(input)
  }, [])

  const signUp = useCallback(async (input: OfficerSignUpInput) => {
    setNotice(null)
    return signUpOfficer(input)
  }, [])

  const signOut = useCallback(async () => {
    await signOutOfSupabase()
    setOfficer(null)
    setSession(null)
    queryClient.clear()
  }, [queryClient])

  const value = useMemo<AuthContextValue>(
    () => ({
      status,
      session,
      officer: status === "ready" ? officer : null,
      notice,
      clearNotice: () => setNotice(null),
      signIn,
      signUp,
      signOut,
      retry: () => setAttempt((count) => count + 1),
    }),
    [status, session, officer, notice, signIn, signUp, signOut],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used inside <AuthProvider>.")
  return context
}
