import { describe, expect, it } from "vitest"
import {
  fieldErrors,
  loginSchema,
  officerSignUpSchema,
  officerToUser,
} from "@/services/authService"

const valid = {
  name: "  Asha   Patil ",
  department: "Soil  Conservation",
  email: "  Asha@Example.GOV.in ",
  state: "Maharashtra",
  district: "Pune",
  locationOperatingOn: "Khadakwasla cluster",
  password: "field2026",
  confirmPassword: "field2026",
}

describe("officer sign-up validation", () => {
  it("normalises whitespace and email case", () => {
    const parsed = officerSignUpSchema.parse(valid)
    expect(parsed.name).toBe("Asha Patil")
    expect(parsed.department).toBe("Soil Conservation")
    expect(parsed.email).toBe("asha@example.gov.in")
  })

  it("accepts Devanagari names", () => {
    expect(
      officerSignUpSchema.safeParse({ ...valid, name: "आशा पाटील" }).success,
    ).toBe(true)
  })

  it("rejects weak, mismatched and malformed input with per-field messages", () => {
    const result = officerSignUpSchema.safeParse({
      ...valid,
      email: "not-an-email",
      state: "Atlantis",
      password: "short",
      confirmPassword: "different",
      district: " ",
    })
    expect(result.success).toBe(false)
    if (result.success) return
    const errors = fieldErrors(result.error)
    expect(errors.email).toBeTruthy()
    expect(errors.state).toBeTruthy()
    expect(errors.password).toBeTruthy()
    expect(errors.district).toBeTruthy()
  })

  it("requires a letter and a number in the password", () => {
    expect(
      officerSignUpSchema.safeParse({
        ...valid,
        password: "onlyletters",
        confirmPassword: "onlyletters",
      }).success,
    ).toBe(false)
  })

  it("flags a confirm-password mismatch on confirmPassword", () => {
    const result = officerSignUpSchema.safeParse({
      ...valid,
      confirmPassword: "field2027",
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(fieldErrors(result.error).confirmPassword).toBe(
        "Passwords do not match.",
      )
    }
  })
})

describe("login validation", () => {
  it("requires email and password", () => {
    const result = loginSchema.safeParse({ email: "", password: "" })
    expect(result.success).toBe(false)
  })
})

describe("officerToUser", () => {
  it("maps the officer row to the app's User with identity fields", () => {
    const user = officerToUser({
      id: "u1",
      officerCode: "OFF-1001",
      name: "Asha Patil",
      email: "a@x.in",
      department: "Soil Conservation",
      locationOperatingOn: "Haveli",
      state: "Maharashtra",
      district: "Pune",
      status: "active",
    })
    expect(user.role).toBe("Field Officer")
    expect(user.initials).toBe("AP")
    expect(user.officerCode).toBe("OFF-1001")
  })
})
